import { YarnItem } from './firebase';

export interface ParseResult {
  demandNo: string;
  demandDate: string;
  items: YarnItem[];
  totalQty: number;
  error?: string;
  debugInfo?: string[];
}

/**
 * Builds a lookup map of Lot -> Godown No from all saved demands.
 */
export function buildGodownLookup(demands: Record<string, { items: YarnItem[] }>): Map<string, string> {
  const lookup = new Map<string, string>();
  for (const demand of Object.values(demands)) {
    if (!demand.items) continue;
    for (const item of demand.items) {
      if (item.lot && item.godownNo) {
        // Normalize lot key to uppercase & trimmed for case-insensitive matching
        const normalizedLot = item.lot.toUpperCase().trim();
        lookup.set(normalizedLot, item.godownNo);
      }
    }
  }
  return lookup;
}

/**
 * Apply godown lookup to parsed items.
 * Matches by lot number (case-insensitive, trimmed).
 */
export function applyGodownLookup(items: YarnItem[], godownLookup: Map<string, string>): YarnItem[] {
  if (!godownLookup || godownLookup.size === 0) return items;
  return items.map(item => {
    const normalizedLot = (item.lot || '').toUpperCase().trim();
    const godownNo = godownLookup.get(normalizedLot) || '';
    return { ...item, godownNo };
  });
}

/**
 * Parses the pasted daily yarn demand data from GMS Composite Knitting software.
 *
 * Uses THREE parsing strategies (in priority order):
 * Method A: Standard tab-separated single-line rows
 * Method B: Line-by-line scanner for multi-line format (MOST RELIABLE for this software)
 * Method C: Normalized proximity search (fallback)
 */

// ─── Method A: Standard tab-separated single-line rows ─────────────────────────
function parseByTabRows(lines: string[]): YarnItem[] | null {
  let headerIdx = -1;
  let headerCells: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const cells = lines[i].split('\t').map(c => c.trim());
    if (
      cells.some(c => c === 'SL') &&
      cells.some(c => c === 'Count') &&
      cells.some(c => c === 'Lot') &&
      cells.some(c => c === 'Demand Qnty')
    ) {
      headerIdx = i;
      headerCells = cells;
      break;
    }
  }

  if (headerIdx === -1) return null;

  const countCol = headerCells.indexOf('Count');
  const brandCol = headerCells.lastIndexOf('Brand');
  const lotCol = headerCells.indexOf('Lot');
  const demandQtyCol = headerCells.indexOf('Demand Qnty');

  if (countCol === -1 || brandCol === -1 || lotCol === -1 || demandQtyCol === -1) return null;

  const items: YarnItem[] = [];
  for (let i = headerIdx + 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    const cells = line.split('\t').map(c => c.trim());
    const firstCell = cells[0];
    if (firstCell === 'Total') break;
    if (!/^\d+$/.test(firstCell)) continue;
    const maxCol = Math.max(countCol, brandCol, lotCol, demandQtyCol);
    if (cells.length <= maxCol) continue;
    const count = cells[countCol] || '';
    const brand = cells[brandCol] || '';
    const lot = cells[lotCol] || '';
    const qtyStr = cells[demandQtyCol] || '';
    const qty = parseFloat(qtyStr);
    if (isNaN(qty) || qty <= 0) continue;
    if (!count || !lot) continue;
    items.push({ count, brand, lot, demandQty: qty });
  }

  return items.length > 0 ? items : null;
}

// ─── Method B: Line-by-line scanner (BEST for multi-line software export) ────
//
// The GMS software exports data in a multi-line format where:
// - Each item has a Brand line, then a Lot line, then a Demand Qnty line
// - Lot is a single token (no spaces) on its own line
// - The line after Lot contains: DEMAND_QTY 0.00 0.00 (tab-separated)
// - Count appears as: NUMBER NUMBER COUNT (Program No, Reqsn No, Count)
//
function parseByLineScan(lines: string[]): { items: YarnItem[]; debug: string[] } | null {
  const debug: string[] = [];

  // Find data section: between header row and Total row
  let dataStart = -1;
  let dataEnd = lines.length;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (/\bSL\b/.test(line) && /\bDemand\s*Qnty\b/.test(line)) {
      dataStart = i + 1;
      debug.push(`Header found at line ${i}`);
      break;
    }
  }

  if (dataStart === -1) {
    debug.push('No header row found with SL + Demand Qnty');
    return null;
  }

  for (let i = dataStart; i < lines.length; i++) {
    if (/^Total\b/i.test(lines[i].trim())) {
      dataEnd = i;
      debug.push(`Total row found at line ${i}`);
      break;
    }
  }

  // Scan lines from dataStart to dataEnd for Lot+Qty pairs
  const items: YarnItem[] = [];
  let lastItemEndLine = dataStart; // Track where last item was found (for Count search range)

  for (let i = dataStart; i < dataEnd - 1; i++) {
    const lineA = lines[i].trim();      // Potential Lot line
    const lineB = lines[i + 1].trim();  // Potential Qty line

    // Skip empty lines
    if (!lineA) continue;

    // ── Lot line criteria ──
    // Must be a single token (no spaces after trimming)
    // Must NOT be too long (lot values are typically 4-15 chars)
    // Must NOT be a pure decimal number
    // Must NOT look like a header/label
    if (/\s/.test(lineA)) continue;                    // Has spaces → not a single token
    if (lineA.length > 25) continue;                    // Too long → not a lot value
    if (/^\d+\.\d+$/.test(lineA)) continue;            // Pure decimal → not a lot
    if (/^(Total|SL|Remark|Color|Type)$/i.test(lineA)) continue;  // Header word

    // ── Qty line criteria ──
    // Next line must start with a positive decimal number
    const qtyMatch = lineB.match(/^(\d+\.\d+)/);
    if (!qtyMatch) continue;

    const qty = parseFloat(qtyMatch[1]);
    if (qty <= 0) continue;

    // Also verify the qty line contains "0.00" after the number
    // (this is the No of Cone and No of Ctn columns which are usually 0)
    const afterQty = lineB.substring(qtyMatch[0].length).trim();
    // We accept any format: with or without trailing 0.00 values

    const lot = lineA;
    debug.push(`Lot found at line ${i}: "${lot}" → Qty: ${qty}`);

    // ── Find Brand: search backward from Lot line, skip empty lines ──
    // Brand is the first non-empty line before the Lot
    let brand = '';
    for (let j = i - 1; j >= lastItemEndLine; j--) {
      const trimmed = lines[j].trim();
      if (trimmed) {
        brand = trimmed;
        break;
      }
    }
    debug.push(`  Brand: "${brand}"`);

    // ── Find Count: search for "NUMBER NUMBER COUNT" pattern ──
    // Look from lastItemEndLine to current position
    let count = '';
    for (let j = lastItemEndLine; j <= i; j++) {
      const match = lines[j].match(/(\d{4,8})\s+(\d{4,8})\s+(\S+)/);
      if (match) {
        count = match[3];
        debug.push(`  Count found at line ${j}: "${count}" (from "${lines[j].trim().substring(0, 60)}")`);
        break;
      }
    }
    if (!count) {
      debug.push(`  Count NOT found for lot ${lot}`);
    }

    if (count && lot) {
      items.push({ count, brand, lot, demandQty: qty, godownNo: '' });
      lastItemEndLine = i + 2; // Move past the qty line
      i++; // Skip the qty line in the main loop
    }
  }

  debug.push(`Line-by-line scan found ${items.length} items`);
  return items.length > 0 ? { items, debug } : null;
}

// ─── Method C: Normalized proximity search (fallback) ─────────────────────────
function parseByProximity(rawText: string): YarnItem[] | null {
  const norm = rawText.replace(/[\r\n\t]+/g, ' ');
  const headerMatch = norm.match(/\bSL\b.*?\bSales\s*Order\b/i);
  const totalMatch = norm.match(/\sTotal\s/i);
  if (!headerMatch) return null;

  const start = (headerMatch.index ?? 0) + (headerMatch[0]?.length ?? 0);
  const end = totalMatch ? (totalMatch.index ?? norm.length) : norm.length;
  if (end <= start) return null;

  const dataSection = norm.substring(start, end);
  const qtyRegex = /(\d+\.\d+)\s+0\.00\s+0\.00/g;
  const qtyPositions: { qty: number; matchStart: number; matchEnd: number }[] = [];

  let m: RegExpExecArray | null;
  while ((m = qtyRegex.exec(dataSection)) !== null) {
    const qty = parseFloat(m[1]);
    if (qty > 0) qtyPositions.push({ qty, matchStart: m.index, matchEnd: m.index + m[0].length });
  }
  if (qtyPositions.length === 0) return null;

  const items: YarnItem[] = [];
  for (let i = 0; i < qtyPositions.length; i++) {
    const { qty, matchStart } = qtyPositions[i];
    const blockStart = i > 0 ? qtyPositions[i - 1].matchEnd : 0;
    const block = dataSection.substring(blockStart, matchStart);
    if (!block.trim()) continue;

    const tokens = block.split(/\s+/).filter(t => t.length > 0);

    let lot = '';
    for (let j = tokens.length - 1; j >= 0; j--) {
      if (tokens[j] !== '0.00') { lot = tokens[j]; break; }
    }

    let brand = '';
    let lotFound = false;
    for (let j = tokens.length - 1; j >= 0; j--) {
      if (!lotFound) { if (tokens[j] === lot) lotFound = true; continue; }
      const t = tokens[j];
      if (t !== '0.00' && !/^\d+(\.\d+)?$/.test(t)) { brand = t; break; }
    }

    let count = '';
    const countMatch = block.match(/(\d{4,8})\s+(\d{4,8})\s+(\S+)/);
    if (countMatch) count = countMatch[3];

    if (count && lot) items.push({ count, brand, lot, demandQty: qty, godownNo: '' });
  }

  return items.length > 0 ? items : null;
}

// ─── Main parser: tries all methods, picks the best result ─────────────────────
export function parseYarnDemandData(rawText: string): ParseResult {
  const debugInfo: string[] = [];

  if (!rawText.trim()) {
    return { demandNo: '', demandDate: '', items: [], totalQty: 0, error: 'Please paste data first.' };
  }

  // 1. Extract Demand Number
  const demandNoMatch = rawText.match(/Demand\s*No\s*:\s*([^\t\n\r]+)/i);
  const demandNo = demandNoMatch ? demandNoMatch[1].trim() : '';
  debugInfo.push(`Demand No: ${demandNo || '(not found)'}`);

  // 2. Extract Demand Date
  const demandDateMatch = rawText.match(/Demand\s*Date\s*:\s*([^\t\n\r]+)/i);
  const demandDate = demandDateMatch ? demandDateMatch[1].trim() : '';
  debugInfo.push(`Demand Date: ${demandDate || '(not found)'}`);

  // 3. Split into lines
  const lines = rawText.split(/\r?\n/);
  debugInfo.push(`Total lines: ${lines.length}`);

  // Show sample lines
  const sampleLines = lines.slice(0, Math.min(6, lines.length));
  sampleLines.forEach((line, idx) => {
    const tabCount = (line.match(/\t/g) || []).length;
    debugInfo.push(`Line ${idx}: [${tabCount} tabs] "${line.substring(0, 80)}${line.length > 80 ? '...' : ''}"`);
  });

  // Collect results from all methods
  const results: { name: string; items: YarnItem[]; debug?: string[] }[] = [];

  // Method A: Tab-separated rows
  debugInfo.push('--- Method A: Tab-separated rows ---');
  const methodA = parseByTabRows(lines);
  debugInfo.push(`Method A: ${methodA ? `${methodA.length} items` : 'No items'}`);
  if (methodA) results.push({ name: 'A', items: methodA });

  // Method B: Line-by-line scanner
  debugInfo.push('--- Method B: Line-by-line scanner ---');
  const methodB = parseByLineScan(lines);
  if (methodB) {
    methodB.debug.forEach(d => debugInfo.push(`  [B] ${d}`));
    debugInfo.push(`Method B: ${methodB.items.length} items`);
    results.push({ name: 'B', items: methodB.items });
  } else {
    debugInfo.push('Method B: No items');
  }

  // Method C: Normalized proximity search
  debugInfo.push('--- Method C: Normalized proximity search ---');
  const methodC = parseByProximity(rawText);
  debugInfo.push(`Method C: ${methodC ? `${methodC.length} items` : 'No items'}`);
  if (methodC) results.push({ name: 'C', items: methodC });

  // Pick the method that found the MOST items (most complete result)
  let rawItems: YarnItem[] | null = null;
  let usedMethod = '';

  if (results.length > 0) {
    results.sort((a, b) => b.items.length - a.items.length);
    rawItems = results[0].items;
    usedMethod = results[0].name;
    debugInfo.push(`>>> Using Method ${usedMethod} (${rawItems.length} items)`);
  }

  if (!rawItems || rawItems.length === 0) {
    return {
      demandNo,
      demandDate,
      items: [],
      totalQty: 0,
      error: 'No yarn items found. Please paste the COMPLETE data including header and all rows.',
      debugInfo,
    };
  }

  // Log found items
  debugInfo.push('--- Parsed Items ---');
  rawItems.forEach((item, idx) => {
    debugInfo.push(`  ${idx + 1}. Count=${item.count}, Brand=${item.brand}, Lot=${item.lot}, Qty=${item.demandQty}`);
  });

  // Combine items with same Count + Lot (brand may differ across databases, so we ignore it for combining)
  const combinedMap = new Map<string, YarnItem>();
  for (const item of rawItems) {
    const key = `${(item.count || '').trim().toUpperCase()}|||${(item.lot || '').trim().toUpperCase()}`;
    if (combinedMap.has(key)) {
      const existing = combinedMap.get(key)!;
      existing.demandQty += item.demandQty;
      // Keep the longer brand name if available
      if (item.brand && (!existing.brand || item.brand.length > existing.brand.length)) {
        existing.brand = item.brand;
      }
      if (item.godownNo) existing.godownNo = item.godownNo;
    } else {
      combinedMap.set(key, { ...item });
    }
  }

  const items = Array.from(combinedMap.values());
  const totalQty = items.reduce((sum, item) => sum + item.demandQty, 0);
  debugInfo.push(`Total items after combine: ${items.length}, Total qty: ${totalQty.toFixed(2)}`);

  return { demandNo, demandDate, items, totalQty, debugInfo };
}
