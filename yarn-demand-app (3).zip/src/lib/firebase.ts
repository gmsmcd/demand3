export const FIREBASE_DB_URL = 'https://demand-53019-default-rtdb.firebaseio.com';
export const YARN_CALC_DB_URL = 'https://yarn-calclutor-default-rtdb.firebaseio.com';

export interface YarnSpec {
  count: string;
  lot: string;
  brand: string;
  coneQty: number;    // cones per bag
  netWeight: number;  // kg per bag
}

export interface YarnItem {
  count: string;
  brand: string;
  lot: string;
  demandQty: number;
  godownNo?: string;
  // Auto-populated from Yarn Calculator DB
  coneQty?: number;      // cones per bag (from yarn spec)
  netWeight?: number;    // kg per bag (from yarn spec)
  ctnQty?: number;       // calculated: floor(demandQty / netWeight)
  calcConeQty?: number;  // calculated: remaining * coneQty
  yarnMatched?: boolean; // whether yarn spec was found
}

export interface SavedDemand {
  demandNo: string;
  demandDate: string;
  items: YarnItem[];
  totalQty: number;
  savedAt: string;
}

export interface ShareToken {
  demandNo: string;
  createdAt: string;
}

export interface WhatsAppContact {
  name: string;
  number: string;
  savedAt: string;
}

// ─── Delivery Slip ──────────────────────────────────────────────────────────

export interface DeliverySlipItem {
  count: string;
  brand: string;
  lot: string;
  kg: number;
  bags: number;
  cones: number;
  godownNo: string;
}

export interface DeliverySlip {
  slipNo: string;
  slipDate: string;
  location: string;
  floor: string;
  items: DeliverySlipItem[];
  createdAt: string;
}

// ─── Demand CRUD ────────────────────────────────────────────────────────────

export async function saveDemandToFirebase(demandNo: string, data: SavedDemand): Promise<boolean> {
  try {
    const res = await fetch(`${FIREBASE_DB_URL}/demands/${demandNo}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return true;
  } catch (error) {
    console.error('Error saving to Firebase:', error);
    throw error;
  }
}

export async function getDemandFromFirebase(demandNo: string): Promise<SavedDemand | null> {
  try {
    const res = await fetch(`${FIREBASE_DB_URL}/demands/${demandNo}.json`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data;
  } catch (error) {
    console.error('Error fetching from Firebase:', error);
    throw error;
  }
}

export async function getAllDemandsFromFirebase(): Promise<Record<string, SavedDemand>> {
  try {
    const res = await fetch(`${FIREBASE_DB_URL}/demands.json`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || {};
  } catch (error) {
    console.error('Error fetching all demands from Firebase:', error);
    throw error;
  }
}

export async function deleteDemandFromFirebase(demandNo: string): Promise<boolean> {
  try {
    const res = await fetch(`${FIREBASE_DB_URL}/demands/${demandNo}.json`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return true;
  } catch (error) {
    console.error('Error deleting from Firebase:', error);
    throw error;
  }
}

// ─── Yarn Calculator DB (yarn-calclutor) ─────────────────────────────────────

export async function getAllYarnSpecs(): Promise<Record<string, YarnSpec>> {
  try {
    const res = await fetch(`${YARN_CALC_DB_URL}/yarns.json`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || {};
  } catch (error) {
    console.error('Error fetching yarn specs:', error);
    return {};
  }
}

/**
 * Build a lookup map from Yarn Calculator DB.
 * Key: "COUNT|||LOT" → YarnSpec  (Brand is IGNORED for matching)
 * If multiple entries have same Count+Lot, the last one wins.
 */
export async function buildYarnSpecLookup(): Promise<Map<string, YarnSpec>> {
  const specs = await getAllYarnSpecs();
  const lookup = new Map<string, YarnSpec>();
  for (const entry of Object.values(specs)) {
    if (entry && entry.count && entry.lot) {
      // Match by Count + Lot only (ignore brand difference)
      const key = `${(entry.count || '').trim().toUpperCase()}|||${(entry.lot || '').trim().toUpperCase()}`;
      lookup.set(key, entry);
    }
  }
  return lookup;
}

/**
 * Enrich demand items with yarn spec data from calculator DB.
 * Matches by Count + Lot ONLY (ignores brand difference between databases).
 * Calculates Ctn/Bag and Cone quantities automatically.
 */
export function enrichItemsWithYarnSpecs(items: YarnItem[], specLookup: Map<string, YarnSpec>): YarnItem[] {
  return items.map(item => {
    // Match by Count + Lot only (ignore brand — brands may differ between databases)
    const key = `${(item.count || '').trim().toUpperCase()}|||${(item.lot || '').trim().toUpperCase()}`;
    const spec = specLookup.get(key);

    if (spec && spec.netWeight && spec.netWeight > 0) {
      const nw = spec.netWeight;
      const cq = spec.coneQty || 0;
      const deliveryQty = item.demandQty / nw;
      const ctnQty = Math.floor(deliveryQty);
      const calcConeQty = parseFloat(((deliveryQty - ctnQty) * cq).toFixed(5));

      return {
        ...item,
        coneQty: spec.coneQty,
        netWeight: spec.netWeight,
        ctnQty,
        calcConeQty,
        yarnMatched: true,
      };
    }

    return { ...item, yarnMatched: false };
  });
}

// ─── Share Tokens ───────────────────────────────────────────────────────────

export async function createShareToken(demandNo: string): Promise<string> {
  const token = crypto.randomUUID().slice(0, 12);
  const data: ShareToken = {
    demandNo,
    createdAt: new Date().toISOString(),
  };
  const res = await fetch(`${FIREBASE_DB_URL}/shares/${token}.json`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to create share token');
  return token;
}

export async function getShareToken(token: string): Promise<ShareToken | null> {
  try {
    const res = await fetch(`${FIREBASE_DB_URL}/shares/${token}.json`);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

// ─── WhatsApp Contacts ──────────────────────────────────────────────────────

export async function getWhatsAppContacts(): Promise<Record<string, WhatsAppContact>> {
  try {
    const res = await fetch(`${FIREBASE_DB_URL}/whatsapp-contacts.json`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) || {};
  } catch {
    return {};
  }
}

export async function saveWhatsAppContact(id: string, contact: WhatsAppContact): Promise<boolean> {
  try {
    const res = await fetch(`${FIREBASE_DB_URL}/whatsapp-contacts/${id}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(contact),
    });
    if (!res.ok) throw new Error('Failed to save contact');
    return true;
  } catch {
    return false;
  }
}

export async function deleteWhatsAppContact(id: string): Promise<boolean> {
  try {
    const res = await fetch(`${FIREBASE_DB_URL}/whatsapp-contacts/${id}.json`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete contact');
    return true;
  } catch {
    return false;
  }
}

// ─── Yarn Spec CRUD (YARN_CALC_DB_URL) ───────────────────────────────────────

export async function saveYarnSpec(id: string, spec: YarnSpec): Promise<boolean> {
  try {
    const now = new Date().toISOString();
    const payload = { ...spec, updatedAt: now };
    const res = await fetch(`${YARN_CALC_DB_URL}/yarns/${id}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return true;
  } catch (error) {
    console.error('Error saving yarn spec:', error);
    return false;
  }
}

export async function deleteYarnSpec(id: string): Promise<boolean> {
  try {
    const res = await fetch(`${YARN_CALC_DB_URL}/yarns/${id}.json`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return true;
  } catch (error) {
    console.error('Error deleting yarn spec:', error);
    return false;
  }
}

// ─── Delivery Slip CRUD (YARN_CALC_DB_URL) ───────────────────────────────────

export async function saveDeliverySlip(slipNo: string, slip: DeliverySlip): Promise<boolean> {
  try {
    const res = await fetch(`${YARN_CALC_DB_URL}/delivery-slips/${slipNo}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(slip),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return true;
  } catch (error) {
    console.error('Error saving delivery slip:', error);
    return false;
  }
}

export async function getAllDeliverySlips(): Promise<Record<string, DeliverySlip>> {
  try {
    const res = await fetch(`${YARN_CALC_DB_URL}/delivery-slips.json`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data || {};
  } catch (error) {
    console.error('Error fetching delivery slips:', error);
    return {};
  }
}

export async function deleteDeliverySlip(slipNo: string): Promise<boolean> {
  try {
    const res = await fetch(`${YARN_CALC_DB_URL}/delivery-slips/${slipNo}.json`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return true;
  } catch (error) {
    console.error('Error deleting delivery slip:', error);
    return false;
  }
}
