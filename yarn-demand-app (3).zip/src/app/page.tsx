'use client';

import { useState, useCallback, useEffect, useMemo, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
  DialogTrigger, DialogFooter, DialogClose,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select, SelectContent, SelectGroup, SelectItem,
  SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import {
  ClipboardPaste, Database, Save, Trash2, Eye, RefreshCw, FileText,
  AlertCircle, CheckCircle2, Loader2, Search, History, Download, Copy,
  Pencil, Warehouse, Share2, Phone, Plus, X, MessageCircle, Camera, Upload,
  Package, Scale, Printer, UploadCloud,
} from 'lucide-react';
import { parseYarnDemandData, buildGodownLookup, applyGodownLookup, ParseResult } from '@/lib/parser';
import {
  saveDemandToFirebase, getAllDemandsFromFirebase, deleteDemandFromFirebase,
  getDemandFromFirebase, createShareToken, getShareToken,
  getWhatsAppContacts, saveWhatsAppContact, deleteWhatsAppContact,
  buildYarnSpecLookup, enrichItemsWithYarnSpecs, getAllYarnSpecs,
  saveYarnSpec, deleteYarnSpec,
  saveDeliverySlip, getAllDeliverySlips, deleteDeliverySlip,
  SavedDemand, YarnItem, WhatsAppContact, YarnSpec, DeliverySlipItem, DeliverySlip,
} from '@/lib/firebase';
import { toast } from 'sonner';
import { useRef } from 'react';

// ─── Shared View Component (rendered when ?view=TOKEN is present) ──────────
function SharedDemandView({ token }: { token: string }) {
  const [demand, setDemand] = useState<SavedDemand | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const share = await getShareToken(token);
        if (!share) { setError('Invalid or expired share link.'); setLoading(false); return; }
        const d = await getDemandFromFirebase(share.demandNo);
        if (!d) { setError('Demand not found. It may have been deleted.'); setLoading(false); return; }
        setDemand(d);
      } catch { setError('Failed to load shared demand.'); }
      finally { setLoading(false); }
    })();
  }, [token]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
      <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
    </div>
  );

  if (error) return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
      <Card className="max-w-md mx-4">
        <CardHeader className="text-center">
          <AlertCircle className="w-12 h-12 mx-auto text-red-500 mb-2" />
          <CardTitle>Link Not Found</CardTitle>
          <CardDescription>{error}</CardDescription>
        </CardHeader>
      </Card>
    </div>
  );

  if (!demand) return null;

  const godownCount = (demand.items || []).filter(i => i.godownNo).length;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100">
      <header className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">Daily Yarn Demand</h1>
              <p className="text-xs text-slate-500">GMS Composite Knitting Ind. Limited</p>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Badge variant="default" className="bg-emerald-600 hover:bg-emerald-700 text-base px-3 py-1">
                    {demand.demandNo}
                  </Badge>
                </CardTitle>
                <CardDescription className="mt-2 text-sm">
                  {demand.demandDate && <><strong>Date:</strong> {demand.demandDate} | </>}
                  <strong>Items:</strong> {(demand.items || []).length} | <strong>Total Qty:</strong> {(demand.totalQty || 0).toFixed(2)}
                  {godownCount > 0 && <> | <strong>Godown assigned:</strong> {godownCount}</>}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    <TableHead className="w-12 text-center">SL</TableHead>
                    <TableHead>Count</TableHead>
                    <TableHead>Brand</TableHead>
                    <TableHead>Lot</TableHead>
                    <TableHead className="text-right">Demand Qnty</TableHead>
                    <TableHead className="font-semibold">Ctn</TableHead>
                    <TableHead className="font-semibold">Cone</TableHead>
                    <TableHead>Godown No.</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(demand.items || []).map((item, idx) => (
                    <TableRow key={idx} className={item.godownNo ? 'bg-amber-50/60' : ''}>
                      <TableCell className="text-center text-slate-500">{idx + 1}</TableCell>
                      <TableCell className="font-medium">{item.count}</TableCell>
                      <TableCell>{item.brand}</TableCell>
                      <TableCell><Badge variant="secondary">{item.lot}</Badge></TableCell>
                      <TableCell className="text-right font-semibold text-emerald-700">
                        {item.demandQty.toFixed(2)}
                      </TableCell>
                      <TableCell className={item.yarnMatched ? 'text-center font-semibold text-blue-700' : 'text-center text-slate-400'}>
                        {item.ctnQty != null && item.ctnQty > 0 ? item.ctnQty : '—'}
                      </TableCell>
                      <TableCell className={item.yarnMatched ? 'text-center font-semibold text-blue-700' : 'text-center text-slate-400'}>
                        {item.calcConeQty != null && item.calcConeQty > 0 ? item.calcConeQty : '—'}
                      </TableCell>
                      <TableCell>
                        {item.godownNo ? (
                          <Badge className="bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-100">
                            <Warehouse className="w-3 h-3 mr-1" />{item.godownNo}
                          </Badge>
                        ) : <span className="text-xs text-slate-400">—</span>}
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableRow className="bg-slate-50 font-bold">
                    <TableCell colSpan={4} className="text-right">Total</TableCell>
                    <TableCell className="text-right text-emerald-700 text-lg">{(demand.totalQty || 0).toFixed(2)}</TableCell>
                    <TableCell />
                    <TableCell />
                    <TableCell />
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>

      <footer className="border-t border-slate-200 bg-white py-4 mt-auto">
        <p className="text-center text-xs text-slate-400">
          GMS Composite Knitting Ind. Limited | Daily Yarn Demand Manager
        </p>
      </footer>
    </div>
  );
}

// ─── Main App Component ─────────────────────────────────────────────────────

function MainApp() {
  const [rawData, setRawData] = useState('');
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoadingDemands, setIsLoadingDemands] = useState(false);
  const [savedDemands, setSavedDemands] = useState<Record<string, SavedDemand>>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [viewingDemand, setViewingDemand] = useState<SavedDemand | null>(null);
  const [viewingDemandNo, setViewingDemandNo] = useState('');
  const [viewGodownFilter, setViewGodownFilter] = useState<Set<string>>(new Set()); // empty = show all

  // Edit demand state
  const [editingDemandNo, setEditingDemandNo] = useState<string | null>(null);
  const [editingItems, setEditingItems] = useState<YarnItem[]>([]);
  const [selectedIndices, setSelectedIndices] = useState<Set<number>>(new Set());
  const [godownInput, setGodownInput] = useState('');
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Share state
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  const [shareLink, setShareLink] = useState('');
  const [isGeneratingLink, setIsGeneratingLink] = useState(false);
  const [shareTargetDemand, setShareTargetDemand] = useState('');

  // WhatsApp contacts
  const [waContacts, setWaContacts] = useState<Record<string, WhatsAppContact>>({});
  const [isWaDialogOpen, setIsWaDialogOpen] = useState(false);
  const [waContactName, setWaContactName] = useState('');
  const [waContactNumber, setWaContactNumber] = useState('');
  const [waSendDialogOpen, setWaSendDialogOpen] = useState(false);
  const [waSendLink, setWaSendLink] = useState('');

  // Yarn spec state (from calculator DB)
  const [yarnSpecLookup, setYarnSpecLookup] = useState<Map<string, YarnSpec>>(new Map());
  const [yarnSpecCount, setYarnSpecCount] = useState(0);

  // Image extraction state
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [isExtracting, setIsExtracting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Yarn Master Data (CRUD) state
  const [yarnSpecsAll, setYarnSpecsAll] = useState<Record<string, YarnSpec>>({});
  const [yarnSearchTerm, setYarnSearchTerm] = useState('');
  const [isYarnDialogOpen, setIsYarnDialogOpen] = useState(false);
  const [isYarnSaving, setIsYarnSaving] = useState(false);
  const [editingYarnId, setEditingYarnId] = useState<string | null>(null);
  const [yarnFormCount, setYarnFormCount] = useState('');
  const [yarnFormBrand, setYarnFormBrand] = useState('');
  const [yarnFormLot, setYarnFormLot] = useState('');
  const [yarnFormConeQty, setYarnFormConeQty] = useState('');
  const [yarnFormNetWeight, setYarnFormNetWeight] = useState('');
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);
  const [bulkImportText, setBulkImportText] = useState('');
  const [isLoadingYarns, setIsLoadingYarns] = useState(false);

  // Delivery Calculator state
  const [calcCount, setCalcCount] = useState('');
  const [calcLot, setCalcLot] = useState('');
  const [calcKg, setCalcKg] = useState('');
  const [calcResult, setCalcResult] = useState<{ bags: number; cones: number } | null>(null);
  const [calcSelectedSpec, setCalcSelectedSpec] = useState<YarnSpec | null>(null);

  // Unmatched demand items (for Calculator) — demand-based approach
  const [calcDemandNo, setCalcDemandNo] = useState('');
  const [calcDemandItems, setCalcDemandItems] = useState<YarnItem[]>([]);
  const [calcDemandLoading, setCalcDemandLoading] = useState(false);
  const [calcSelectedUnmatched, setCalcSelectedUnmatched] = useState<YarnItem | null>(null);

  // Manual weight entry (for items not in Yarn DB)
  const [manualConeQty, setManualConeQty] = useState('');
  const [manualNetWeight, setManualNetWeight] = useState('');
  const [isSavingManual, setIsSavingManual] = useState(false);
  const [manualCalcResult, setManualCalcResult] = useState<{ bags: number; cones: number } | null>(null);

  // Delivery Slip state
  const [slipDate, setSlipDate] = useState('');
  const [slipLocation, setSlipLocation] = useState('');
  const [slipFloor, setSlipFloor] = useState('');
  const [slipItems, setSlipItems] = useState<DeliverySlipItem[]>([]);
  const [savedSlips, setSavedSlips] = useState<Record<string, DeliverySlip>>({});
  const [isLoadingSlips, setIsLoadingSlips] = useState(false);
  const [isSavingSlip, setIsSavingSlip] = useState(false);

  const searchParams = useSearchParams();
  const viewToken = searchParams.get('view');

  const godownLookup = useMemo(() => buildGodownLookup(savedDemands), [savedDemands]);

  // ─── Load data ────────────────────────────────────────────────────────────
  const loadDemands = useCallback(async () => {
    setIsLoadingDemands(true);
    try {
      const data = await getAllDemandsFromFirebase();
      setSavedDemands(data);
    } catch { toast.error('Failed to load demands.'); }
    finally { setIsLoadingDemands(false); }
  }, []);

  const loadWaContacts = useCallback(async () => {
    try {
      const data = await getWhatsAppContacts();
      setWaContacts(data);
    } catch { /* silent */ }
  }, []);

  const loadYarnSpecs = useCallback(async () => {
    try {
      const lookup = await buildYarnSpecLookup();
      setYarnSpecLookup(lookup);
      setYarnSpecCount(lookup.size);
      // Also load all raw yarn specs for master data management
      const all = await getAllYarnSpecs();
      setYarnSpecsAll(all);
    } catch { /* silent */ }
  }, []);

  const loadSlips = useCallback(async () => {
    setIsLoadingSlips(true);
    try {
      const data = await getAllDeliverySlips();
      setSavedSlips(data);
    } catch { toast.error('Failed to load delivery slips.'); }
    finally { setIsLoadingSlips(false); }
  }, []);

  useEffect(() => { loadDemands(); loadWaContacts(); loadYarnSpecs(); loadSlips(); }, [loadDemands, loadWaContacts, loadYarnSpecs, loadSlips]);

  // ─── Yarn Master Data handlers ──────────────────────────────────────────
  const handleOpenAddYarn = useCallback(() => {
    setEditingYarnId(null);
    setYarnFormCount('');
    setYarnFormBrand('');
    setYarnFormLot('');
    setYarnFormConeQty('');
    setYarnFormNetWeight('');
    setIsYarnDialogOpen(true);
  }, []);

  const handleOpenEditYarn = useCallback((id: string) => {
    const spec = yarnSpecsAll[id];
    if (!spec) return;
    setEditingYarnId(id);
    setYarnFormCount(spec.count || '');
    setYarnFormBrand(spec.brand || '');
    setYarnFormLot(spec.lot || '');
    setYarnFormConeQty(String(spec.coneQty || ''));
    setYarnFormNetWeight(String(spec.netWeight || ''));
    setIsYarnDialogOpen(true);
  }, [yarnSpecsAll]);

  const handleSaveYarn = useCallback(async () => {
    if (!yarnFormCount.trim() || !yarnFormBrand.trim() || !yarnFormLot.trim()) {
      toast.error('Count, Brand, and Lot are required.');
      return;
    }
    const coneQty = parseFloat(yarnFormConeQty) || 0;
    const netWeight = parseFloat(yarnFormNetWeight) || 0;
    if (coneQty <= 0 || netWeight <= 0) {
      toast.error('Cone Qty and Net Weight must be positive numbers.');
      return;
    }
    setIsYarnSaving(true);
    try {
      const spec: YarnSpec = {
        count: yarnFormCount.trim(),
        brand: yarnFormBrand.trim(),
        lot: yarnFormLot.trim(),
        coneQty,
        netWeight,
      };
      const id = editingYarnId || `${spec.count}_${spec.lot}_${Date.now()}`;
      const ok = await saveYarnSpec(id, spec);
      if (ok) {
        toast.success(editingYarnId ? 'Yarn spec updated!' : 'Yarn spec added!');
        setIsYarnDialogOpen(false);
        await loadYarnSpecs();
      } else toast.error('Failed to save yarn spec.');
    } finally { setIsYarnSaving(false); }
  }, [yarnFormCount, yarnFormBrand, yarnFormLot, yarnFormConeQty, yarnFormNetWeight, editingYarnId, loadYarnSpecs]);

  const handleDeleteYarn = useCallback(async (id: string) => {
    const ok = await deleteYarnSpec(id);
    if (ok) { toast.success('Yarn spec deleted.'); await loadYarnSpecs(); }
    else toast.error('Failed to delete.');
  }, [loadYarnSpecs]);

  const handleBulkImport = useCallback(async () => {
    if (!bulkImportText.trim()) { toast.error('Paste yarn data first.'); return; }
    setIsYarnSaving(true);
    let imported = 0;
    const lines = bulkImportText.trim().split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      let count = '', brand = '', lot = '', coneQty = 0, netWeight = 0;
      // Try comma-separated: Count, Brand, Lot, ConeQty, NetWeight
      if (trimmed.includes(',')) {
        const parts = trimmed.split(',').map(p => p.trim());
        if (parts.length >= 5) {
          count = parts[0]; brand = parts[1]; lot = parts[2];
          coneQty = parseFloat(parts[3]) || 0; netWeight = parseFloat(parts[4]) || 0;
        } else if (parts.length >= 3) {
          count = parts[0]; brand = parts[1]; lot = parts[2];
          coneQty = parseFloat(parts[3]) || 0; netWeight = parseFloat(parts[4]) || 0;
        }
      }
      // Try colon-separated: Count:Brand:ConeQty:NetWeight
      if (!count && trimmed.includes(':')) {
        const parts = trimmed.split(':').map(p => p.trim());
        if (parts.length >= 4) {
          count = parts[0]; brand = parts[1];
          coneQty = parseFloat(parts[2]) || 0; netWeight = parseFloat(parts[3]) || 0;
          lot = '';
        } else if (parts.length >= 3) {
          count = parts[0]; lot = parts[1];
          coneQty = parseFloat(parts[2]) || 0; netWeight = parseFloat(parts[3]) || 0;
          brand = '';
        }
      }
      if (count && coneQty > 0 && netWeight > 0) {
        const id = `${count}_${lot || '_'}_${Date.now()}_${imported}`;
        await saveYarnSpec(id, { count, brand, lot, coneQty, netWeight });
        imported++;
      }
    }
    setIsYarnSaving(false);
    if (imported > 0) {
      toast.success(`Imported ${imported} yarn spec(s)!`);
      setBulkImportText('');
      setIsBulkImportOpen(false);
      await loadYarnSpecs();
    } else {
      toast.error('No valid yarn data found. Check format.');
    }
  }, [bulkImportText, loadYarnSpecs]);

  // ─── Delivery Calculator handlers ───────────────────────────────────────
  const uniqueCounts = useMemo(() => {
    const set = new Set<string>();
    for (const spec of Object.values(yarnSpecsAll)) {
      if (spec?.count) set.add(spec.count);
    }
    return Array.from(set).sort();
  }, [yarnSpecsAll]);

  const lotsForCount = useMemo(() => {
    if (!calcCount) return [];
    const lots: { lot: string; spec: YarnSpec }[] = [];
    for (const spec of Object.values(yarnSpecsAll)) {
      if (spec?.count === calcCount && spec?.lot) {
        lots.push({ lot: spec.lot, spec });
      }
    }
    return lots.sort((a, b) => a.lot.localeCompare(b.lot));
  }, [yarnSpecsAll, calcCount]);

  const handleCalcSelectCount = useCallback((count: string) => {
    setCalcCount(count);
    setCalcLot('');
    setCalcSelectedSpec(null);
    setCalcResult(null);
  }, []);

  const handleCalcSelectLot = useCallback((lot: string) => {
    setCalcLot(lot);
    const found = lotsForCount.find(l => l.lot === lot);
    setCalcSelectedSpec(found?.spec || null);
    setCalcResult(null);
  }, [lotsForCount]);

  const handleCalculate = useCallback(() => {
    if (!calcSelectedSpec || !calcKg) { toast.error('Select a yarn and enter Kg.'); return; }
    const kg = parseFloat(calcKg) || 0;
    if (kg <= 0) { toast.error('Kg must be a positive number.'); return; }
    const nw = calcSelectedSpec.netWeight;
    const cq = calcSelectedSpec.coneQty || 0;
    const deliveryQty = kg / nw;
    const bags = Math.floor(deliveryQty);
    const cones = parseFloat(((deliveryQty - bags) * cq).toFixed(2));
    setCalcResult({ bags, cones });
  }, [calcSelectedSpec, calcKg]);

  const handleAddToSlip = useCallback(() => {
    if (!calcResult || !calcSelectedSpec) return;
    const newItem: DeliverySlipItem = {
      count: calcSelectedSpec.count,
      brand: calcSelectedSpec.brand,
      lot: calcSelectedSpec.lot,
      kg: parseFloat(calcKg) || 0,
      bags: calcResult.bags,
      cones: calcResult.cones,
      godownNo: '',
    };
    setSlipItems(prev => [...prev, newItem]);
    toast.success('Added to delivery slip!');
    setCalcKg('');
    setCalcResult(null);
  }, [calcResult, calcSelectedSpec, calcKg]);

  const handleRemoveSlipItem = useCallback((idx: number) => {
    setSlipItems(prev => prev.filter((_, i) => i !== idx));
  }, []);

  const handleSlipItemGodown = useCallback((idx: number, godownNo: string) => {
    setSlipItems(prev => prev.map((item, i) => i === idx ? { ...item, godownNo } : item));
  }, []);

  // ─── Load Demand Items for Calculator ──────────────────────────────────
  const handleCalcDemandSelect = useCallback((demandNo: string) => {
    setCalcDemandNo(demandNo);
    setCalcSelectedUnmatched(null);
    setManualConeQty('');
    setManualNetWeight('');
    setManualCalcResult(null);
    if (!demandNo) {
      setCalcDemandItems([]);
      return;
    }
    setCalcDemandLoading(true);
    const demand = savedDemands[demandNo];
    if (demand?.items) {
      // Re-enrich items with latest yarn spec data
      const enriched = enrichItemsWithYarnSpecs(demand.items, yarnSpecLookup);
      setCalcDemandItems(enriched);
    } else {
      setCalcDemandItems([]);
    }
    setCalcDemandLoading(false);
  }, [savedDemands, yarnSpecLookup]);

  // ─── Select Unmatched Item for Weight Entry ────────────────────────────
  const handleSelectUnmatched = useCallback((item: YarnItem) => {
    setCalcSelectedUnmatched(item);
    setManualConeQty('');
    setManualNetWeight('');
    setManualCalcResult(null);
  }, []);

  // ─── Calculate with Manual Weights ─────────────────────────────────────
  const handleManualCalculate = useCallback(() => {
    const cq = parseFloat(manualConeQty) || 0;
    const nw = parseFloat(manualNetWeight) || 0;
    if (cq <= 0 || nw <= 0) { toast.error('Enter valid Cone Qty and Net Weight.'); return; }
    if (!calcSelectedUnmatched) return;
    const kg = calcSelectedUnmatched.demandQty || 0;
    if (kg <= 0) { toast.error('Demand qty is 0.'); return; }
    const deliveryQty = kg / nw;
    const bags = Math.floor(deliveryQty);
    const cones = parseFloat(((deliveryQty - bags) * cq).toFixed(2));
    setManualCalcResult({ bags, cones });
  }, [manualConeQty, manualNetWeight, calcSelectedUnmatched]);

  // ─── Save Manual Yarn Spec to Database ────────────────────────────────
  const handleSaveManualSpec = useCallback(async () => {
    const item = calcSelectedUnmatched;
    if (!item?.count || !item?.lot) { toast.error('Count and Lot are required.'); return; }
    const coneQty = parseFloat(manualConeQty) || 0;
    const netWeight = parseFloat(manualNetWeight) || 0;
    if (coneQty <= 0 || netWeight <= 0) { toast.error('Cone Qty and Net Weight must be positive.'); return; }
    if (!calcDemandNo) return;
    setIsSavingManual(true);
    try {
      // 1. Save to Yarn Database (yarn calculator DB)
      const spec: YarnSpec = {
        count: item.count.trim(),
        brand: item.brand?.trim() || '',
        lot: item.lot.trim(),
        coneQty,
        netWeight,
      };
      const specId = `CL_${spec.count.trim().toUpperCase()}|||${spec.lot.trim().toUpperCase()}`;
      const ok = await saveYarnSpec(specId, spec);
      if (!ok) { toast.error('Failed to save yarn spec.'); return; }

      // 2. Build new yarn spec lookup including the newly saved spec
      const newLookup = new Map(yarnSpecLookup);
      const matchKey = `${spec.count.trim().toUpperCase()}|||${spec.lot.trim().toUpperCase()}`;
      newLookup.set(matchKey, spec);

      // 3. Re-enrich ALL items in the current demand using updated lookup
      const currentDemand = savedDemands[calcDemandNo];
      if (currentDemand?.items) {
        const rawItems = currentDemand.items.map(it => ({
          ...it,
          // Clear old matched data so enrichment recalculates fresh
          coneQty: undefined,
          netWeight: undefined,
          ctnQty: undefined,
          calcConeQty: undefined,
          yarnMatched: undefined,
        }));
        const enrichedItems = enrichItemsWithYarnSpecs(rawItems, newLookup);

        // 4. Update calculator table IMMEDIATELY
        setCalcDemandItems(enrichedItems);

        // 5. Update yarn spec lookup state
        setYarnSpecLookup(newLookup);

        // 6. Save updated demand to Firebase (background)
        saveDemandToFirebase(calcDemandNo, {
          ...currentDemand,
          items: enrichedItems,
          savedAt: new Date().toISOString(),
        }).then(() => {
          // On successful Firebase save, refresh everything
          loadDemands();
          const allSpecs = { ...yarnSpecsAll };
          allSpecs[specId] = spec;
          setYarnSpecsAll(allSpecs);
        }).catch(() => {
          toast.error('Demand saved to Yarn DB but failed to update demand in Firebase.');
        });
      }

      toast.success(`Saved! ${spec.count} / ${spec.lot} added to Yarn DB. Demand updated with Ctn/Cone.`);
      // Reset manual form
      setCalcSelectedUnmatched(null);
      setManualConeQty('');
      setManualNetWeight('');
      setManualCalcResult(null);
    } catch {
      toast.error('Failed to save yarn spec.');
    } finally { setIsSavingManual(false); }
  }, [calcSelectedUnmatched, manualConeQty, manualNetWeight, loadDemands, calcDemandNo, yarnSpecLookup, savedDemands, yarnSpecsAll]);

  // ─── Delivery Slip handlers ─────────────────────────────────────────────
  const handleSaveSlip = useCallback(async () => {
    if (slipItems.length === 0) { toast.error('Add items to the slip first.'); return; }
    setIsSavingSlip(true);
    try {
      const slipNo = `DS-${Date.now().toString(36).toUpperCase()}`;
      const slip: DeliverySlip = {
        slipNo,
        slipDate: slipDate || new Date().toISOString().split('T')[0],
        location: slipLocation.trim(),
        floor: slipFloor.trim(),
        items: slipItems,
        createdAt: new Date().toISOString(),
      };
      const ok = await saveDeliverySlip(slipNo, slip);
      if (ok) {
        toast.success(`Delivery slip ${slipNo} saved!`);
        setSlipItems([]);
        setSlipDate('');
        setSlipLocation('');
        setSlipFloor('');
        await loadSlips();
      } else toast.error('Failed to save slip.');
    } finally { setIsSavingSlip(false); }
  }, [slipItems, slipDate, slipLocation, slipFloor, loadSlips]);

  const handleDeleteSlip = useCallback(async (slipNo: string) => {
    const ok = await deleteDeliverySlip(slipNo);
    if (ok) { toast.success('Slip deleted.'); await loadSlips(); }
    else toast.error('Failed to delete slip.');
  }, [loadSlips]);

  const handlePrintSlip = useCallback((slip: DeliverySlip) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) { toast.error('Pop-up blocked. Allow pop-ups for printing.'); return; }
    const itemsHtml = slip.items.map((item, idx) => `
      <tr>
        <td style="padding:3px 6px;font-size:11px;">${idx + 1}</td>
        <td style="padding:3px 6px;font-size:11px;">${item.count}</td>
        <td style="padding:3px 6px;font-size:11px;">${item.brand}</td>
        <td style="padding:3px 6px;font-size:11px;">${item.lot}</td>
        <td style="padding:3px 6px;font-size:11px;text-align:right;">${item.kg.toFixed(2)}</td>
        <td style="padding:3px 6px;font-size:11px;text-align:center;">${item.bags}</td>
        <td style="padding:3px 6px;font-size:11px;text-align:center;">${item.cones}</td>
        <td style="padding:3px 6px;font-size:11px;">${item.godownNo || '-'}</td>
      </tr>`).join('');
    const totalKg = slip.items.reduce((s, i) => s + i.kg, 0);
    const slipCard = `
      <div style="border:1px solid #333;padding:8px;margin:4px;page-break-inside:avoid;flex:1;min-width:0;">
        <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #666;padding-bottom:4px;margin-bottom:4px;">
          <strong style="font-size:12px;">GMS Composite Knitting Ind. Ltd.</strong>
          <strong style="font-size:11px;color:#555;">${slip.slipNo}</strong>
        </div>
        <div style="font-size:10px;color:#555;margin-bottom:4px;">
          Date: ${slip.slipDate} | Location: ${slip.location || '-'} | Floor: ${slip.floor || '-'}
        </div>
        <table style="width:100%;border-collapse:collapse;font-family:sans-serif;">
          <thead>
            <tr style="background:#f0f0f0;">
              <th style="padding:2px 6px;font-size:10px;text-align:left;">SL</th>
              <th style="padding:2px 6px;font-size:10px;text-align:left;">Count</th>
              <th style="padding:2px 6px;font-size:10px;text-align:left;">Brand</th>
              <th style="padding:2px 6px;font-size:10px;text-align:left;">Lot</th>
              <th style="padding:2px 6px;font-size:10px;text-align:right;">Kg</th>
              <th style="padding:2px 6px;font-size:10px;text-align:center;">Bags</th>
              <th style="padding:2px 6px;font-size:10px;text-align:center;">Cones</th>
              <th style="padding:2px 6px;font-size:10px;text-align:left;">Godown</th>
            </tr>
          </thead>
          <tbody>${itemsHtml}
            <tr style="font-weight:bold;background:#f0f0f0;">
              <td colspan="4" style="padding:3px 6px;font-size:11px;text-align:right;">Total</td>
              <td style="padding:3px 6px;font-size:11px;text-align:right;">${totalKg.toFixed(2)}</td>
              <td colspan="3"></td>
            </tr>
          </tbody>
        </table>
      </div>`;
    printWindow.document.write(`<!DOCTYPE html><html><head><title>Delivery Slip ${slip.slipNo}</title>
      <style>@media print { @page { size: A4; margin: 10mm; } body { margin: 0; } }</style>
      </head><body style="margin:0;font-family:sans-serif;">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
        ${slipCard}${slipCard}
      </div>
      <script>window.onload=function(){window.print();}<\/script>
      </body></html>`);
    printWindow.document.close();
  }, []);

  // ─── Image extraction ──────────────────────────────────────────────
  const handleImageFile = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file (PNG, JPG, etc.)');
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error('Image is too large. Maximum 20MB.');
      return;
    }
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = (e) => setImagePreview(e.target?.result as string);
    reader.readAsDataURL(file);
  }, []);

  const handlePasteImage = useCallback((e: React.ClipboardEvent | ClipboardEvent) => {
    const items = 'clipboardData' in e ? e.clipboardData?.items : (e as ClipboardEvent).clipboardData?.items;
    if (!items) return;
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.startsWith('image/')) {
        const file = items[i].getAsFile();
        if (file) {
          handleImageFile(file);
          toast.success('Image pasted! Click "Extract from Image" to process.');
        }
        return;
      }
    }
  }, [handleImageFile]);

  const handleExtractFromImage = useCallback(async () => {
    if (!imageFile) { toast.error('No image to extract from.'); return; }
    setIsExtracting(true);
    setParseResult(null);
    try {
      const formData = new FormData();
      formData.append('image', imageFile);
      const res = await fetch('/api/extract-image', {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        toast.error(data.error || 'Failed to extract data from image.');
        return;
      }
      // Apply godown lookup
      const itemsWithGodown = applyGodownLookup(data.items || [], godownLookup);
      // Enrich with yarn spec data from calculator DB
      const enrichedItems = enrichItemsWithYarnSpecs(itemsWithGodown, yarnSpecLookup);
      const totalQty = enrichedItems.reduce((sum: number, item: { demandQty: number }) => sum + item.demandQty, 0);
      const result: ParseResult = {
        demandNo: data.demandNo || '',
        demandDate: data.demandDate || '',
        items: enrichedItems,
        totalQty,
        debugInfo: [
          `Method: Image OCR (VLM)`,
          `Raw items found: ${data.rawItemCount || enrichedItems.length}`,
          `Items after combine: ${enrichedItems.length}`,
          `Total qty: ${totalQty.toFixed(2)}`,
        ],
      };
      setParseResult(result);
      const autoDetected = enrichedItems.filter(i => i.godownNo).length;
      const yarnMatched = enrichedItems.filter(i => i.yarnMatched).length;
      let extra = '';
      if (autoDetected > 0) extra += ` (${autoDetected} godown auto-detected`;
      if (yarnMatched > 0) extra += `${extra ? ', ' : ' ('}${yarnMatched}/${enrichedItems.length} yarn specs matched`;
      toast.success(`Extracted ${enrichedItems.length} item(s) from image. Total: ${totalQty.toFixed(2)}${extra ? `${extra})` : ''}`);
    } catch {
      toast.error('Failed to connect to server for image extraction.');
    } finally {
      setIsExtracting(false);
    }
  }, [imageFile, godownLookup, yarnSpecLookup]);

  const clearImage = useCallback(() => {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  }, []);

  // ─── Parse ────────────────────────────────────────────────────────────────
  const handleParse = useCallback(() => {
    setIsParsing(true);
    setTimeout(() => {
      const result = parseYarnDemandData(rawData);
      // Apply godown number auto-detection from saved demands
      let enrichedItems = applyGodownLookup(result.items, godownLookup);
      // Enrich with yarn spec data from calculator DB
      enrichedItems = enrichItemsWithYarnSpecs(enrichedItems, yarnSpecLookup);
      result.items = enrichedItems;
      setParseResult(result);
      setIsParsing(false);
      if (result.error) { toast.error(result.error); }
      else {
        const autoDetected = result.items.filter(i => i.godownNo).length;
        const yarnMatched = result.items.filter(i => i.yarnMatched).length;
        const msg = `Parsed ${result.items.length} item(s). Total: ${result.totalQty.toFixed(2)}`;
        let extra = '';
        if (autoDetected > 0) extra += ` (${autoDetected} godown auto-detected`;
        if (yarnMatched > 0) extra += `${extra ? ', ' : ' ('}${yarnMatched}/${result.items.length} yarn specs matched`;
        toast.success(extra ? `${msg}${extra})` : msg);
      }
    }, 300);
  }, [rawData, godownLookup, yarnSpecLookup]);

  // ─── Save demand ──────────────────────────────────────────────────────────
  const handleSave = useCallback(async () => {
    if (!parseResult || parseResult.items.length === 0) { toast.error('No valid demand data to save.'); return; }
    // Auto-generate demand number if not found in pasted data
    const demandNo = parseResult.demandNo || `DM-${Date.now().toString(36).toUpperCase()}`;
    setIsSaving(true);
    try {
      await saveDemandToFirebase(demandNo, {
        demandNo,
        demandDate: parseResult.demandDate || new Date().toISOString().split('T')[0],
        items: parseResult.items,
        totalQty: parseResult.totalQty,
        savedAt: new Date().toISOString(),
      });
      toast.success(`Demand ${demandNo} saved successfully!`);
      // Clear form after successful save
      setRawData('');
      setParseResult(null);
      await loadDemands();
    } catch { toast.error('Failed to save to Firebase.'); }
    finally { setIsSaving(false); }
  }, [parseResult, loadDemands]);

  const handleDelete = useCallback(async (demandNo: string) => {
    try { await deleteDemandFromFirebase(demandNo); toast.success('Deleted.'); await loadDemands(); }
    catch { toast.error('Failed to delete.'); }
  }, [loadDemands]);

  // ─── Edit demand ──────────────────────────────────────────────────────────
  const handleOpenEdit = useCallback((demandNo: string) => {
    const demand = savedDemands[demandNo];
    if (!demand) return;
    setEditingDemandNo(demandNo);
    setEditingItems(JSON.parse(JSON.stringify(demand.items)));
    setSelectedIndices(new Set());
    setGodownInput('');
    setIsEditDialogOpen(true);
  }, [savedDemands]);

  const toggleSelectAll = useCallback(() => {
    if (selectedIndices.size === editingItems.length) setSelectedIndices(new Set());
    else setSelectedIndices(new Set(editingItems.map((_, i) => i)));
  }, [selectedIndices.size, editingItems.length]);

  const toggleSelect = useCallback((idx: number) => {
    setSelectedIndices(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx); else next.add(idx);
      return next;
    });
  }, []);

  const handleApplyGodown = useCallback(() => {
    if (selectedIndices.size === 0) { toast.error('Select at least one item.'); return; }
    if (!godownInput.trim()) { toast.error('Enter a godown number.'); return; }
    setEditingItems(prev => prev.map((item, idx) =>
      selectedIndices.has(idx) ? { ...item, godownNo: godownInput.trim() } : item
    ));
    toast.success(`Godown "${godownInput.trim()}" applied to ${selectedIndices.size} item(s).`);
    setSelectedIndices(new Set());
    setGodownInput('');
  }, [editingItems, selectedIndices, godownInput]);

  const handleSaveEdit = useCallback(async () => {
    if (!editingDemandNo) return;
    const demand = savedDemands[editingDemandNo];
    if (!demand) return;
    setIsSaving(true);
    try {
      await saveDemandToFirebase(editingDemandNo, { ...demand, items: editingItems, savedAt: new Date().toISOString() });
      toast.success('Demand updated!');
      setIsEditDialogOpen(false);
      await loadDemands();
    } catch { toast.error('Failed to update.'); }
    finally { setIsSaving(false); }
  }, [editingDemandNo, savedDemands, editingItems, loadDemands]);

  // ─── Share demand ─────────────────────────────────────────────────────────
  const handleGenerateShareLink = useCallback(async (demandNo: string) => {
    setShareTargetDemand(demandNo);
    setShareLink('');
    setIsShareDialogOpen(true);
    setIsGeneratingLink(true);
    try {
      const token = await createShareToken(demandNo);
      const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
      setShareLink(`${baseUrl}/?view=${token}`);
    } catch { toast.error('Failed to generate share link.'); }
    finally { setIsGeneratingLink(false); }
  }, []);

  const handleCopyLink = useCallback(() => {
    navigator.clipboard.writeText(shareLink).then(() => toast.success('Link copied!'));
  }, [shareLink]);

  // ─── WhatsApp contacts ────────────────────────────────────────────────────
  const handleAddWaContact = useCallback(async () => {
    if (!waContactName.trim() || !waContactNumber.trim()) { toast.error('Enter name and number.'); return; }
    const id = Date.now().toString();
    const ok = await saveWhatsAppContact(id, {
      name: waContactName.trim(),
      number: waContactNumber.trim().replace(/[^0-9+]/g, ''),
      savedAt: new Date().toISOString(),
    });
    if (ok) {
      toast.success('Contact saved!');
      setWaContactName('');
      setWaContactNumber('');
      await loadWaContacts();
    } else toast.error('Failed to save contact.');
  }, [waContactName, waContactNumber, loadWaContacts]);

  const handleDeleteWaContact = useCallback(async (id: string) => {
    const ok = await deleteWhatsAppContact(id);
    if (ok) { toast.success('Contact deleted.'); await loadWaContacts(); }
    else toast.error('Failed to delete.');
  }, [loadWaContacts]);

  const handleSendWhatsApp = useCallback((number: string) => {
    // Format WhatsApp number: remove leading + or 00, prepend with country code if needed
    const clean = number.replace(/[^0-9]/g, '');
    const msg = encodeURIComponent(
      `Assalamu Alaikum! 📋\n\nDaily Yarn Demand from GMS Composite Knitting:\n${shareLink}\n\n(Click to view the demand details)`
    );
    window.open(`https://wa.me/${clean}?text=${msg}`, '_blank');
    toast.success('Opening WhatsApp...');
  }, [shareLink]);

  const handleOpenWaSend = useCallback(async (demandNo: string) => {
    const link = await createShareToken(demandNo);
    const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
    setWaSendLink(`${baseUrl}/?view=${link}`);
    setWaSendDialogOpen(true);
  }, []);

  // ─── Godown Filter Helpers for View Dialog ─────────────────────────────
  const getUniqueGodowns = useCallback((demand: SavedDemand): string[] => {
    const godowns = new Set<string>();
    (demand?.items || []).forEach(item => {
      if (item.godownNo) godowns.add(item.godownNo);
    });
    return Array.from(godowns).sort();
  }, []);

  const getFilteredDemandItems = useCallback((demand: SavedDemand): YarnItem[] => {
    const items = demand?.items || [];
    if (viewGodownFilter.size === 0) return items; // no filter = show all
    return items.filter(item => item.godownNo && viewGodownFilter.has(item.godownNo));
  }, [viewGodownFilter]);

  const handleToggleGodownFilter = useCallback((godown: string) => {
    setViewGodownFilter(prev => {
      const next = new Set(prev);
      if (next.has(godown)) next.delete(godown);
      else next.add(godown);
      return next;
    });
  }, []);

  const handleSelectAllGodowns = useCallback((godowns: string[]) => {
    setViewGodownFilter(new Set(godowns));
  }, []);

  const handleClearGodownFilter = useCallback(() => {
    setViewGodownFilter(new Set());
  }, []);

  // ─── Download as Image ─────────────────────────────────────────────────
  const handleDownloadAsImage = useCallback((items: YarnItem[], demand: SavedDemand, demandNo: string, filteredLabel?: string) => {
    const total = items.reduce((sum, item) => sum + item.demandQty, 0);
    const godownCount = items.filter(i => i.godownNo).length;

    const canvas = document.createElement('canvas');
    const scale = 2;
    const pad = 28;
    const cols = [32, 100, 100, 100, 100, 60, 60, 110]; // column widths
    const totalW = cols.reduce((a, b) => a + b, 0);
    const rowH = 34;
    const headerH = 44;
    const metaH = 36;
    const topH = 70;
    const footerH = 36;
    const H = topH + headerH + metaH + items.length * rowH + rowH + footerH;

    canvas.width = (totalW + pad * 2) * scale;
    canvas.height = H * scale;
    const ctx = canvas.getContext('2d')!;
    ctx.scale(scale, scale);

    // Helper: rounded rect
    const drawRoundRect = (x: number, y: number, w: number, h: number, r: number) => {
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + r);
      ctx.lineTo(x + w, y + h - r);
      ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      ctx.lineTo(x + r, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
    };

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, totalW + pad * 2, H);

    // --- Header ---
    ctx.fillStyle = '#059669';
    drawRoundRect(pad, pad, 40, 40, 8);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Y', pad + 20, pad + 27);

    ctx.textAlign = 'left';
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 17px sans-serif';
    ctx.fillText('Daily Yarn Demand', pad + 52, pad + 24);
    ctx.fillStyle = '#64748b';
    ctx.font = '11px sans-serif';
    ctx.fillText('GMS Composite Knitting Ind. Limited', pad + 52, pad + 42);

    // --- Meta info ---
    let mx = pad;
    const my = pad + topH;
    // Badge
    ctx.fillStyle = '#059669';
    const badgeText = demandNo;
    ctx.font = 'bold 13px sans-serif';
    const bw = ctx.measureText(badgeText).width + 24;
    drawRoundRect(mx, my, bw, 26, 5);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.fillText(badgeText, mx + 12, my + 17);
    mx += bw + 14;

    ctx.font = '12px sans-serif';
    ctx.fillStyle = '#64748b';
    if (demand.demandDate) {
      ctx.fillText(`Date: ${demand.demandDate}`, mx, my + 17);
      mx += ctx.measureText(`Date: ${demand.demandDate}`).width + 16;
    }
    ctx.fillText(`Items: ${items.length}`, mx, my + 17);
    mx += ctx.measureText(`Items: ${items.length}`).width + 16;
    ctx.fillText(`Total: ${total.toFixed(2)}`, mx, my + 17);
    if (godownCount > 0) {
      mx += ctx.measureText(`Total: ${total.toFixed(2)}`).width + 16;
      ctx.fillText(`Godown: ${godownCount}`, mx, my + 17);
    }
    if (filteredLabel) {
      mx += ctx.measureText(`Godown: ${godownCount}`).width + 16;
      ctx.fillStyle = '#92400e';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText(filteredLabel, mx, my + 17);
    }

    // --- Table ---
    const tableY = my + metaH;
    const headers = ['SL', 'Count', 'Brand', 'Lot', 'Demand Qnty', 'Ctn', 'Cone', 'Godown No.'];

    // Header row
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(pad, tableY, totalW, headerH);
    ctx.fillStyle = '#94a3b8';
    ctx.font = 'bold 11px sans-serif';
    let cx = pad;
    headers.forEach((h, i) => {
      ctx.textAlign = i === 0 ? 'center' : i === 4 ? 'right' : 'left';
      if (i === 5 || i === 6) ctx.textAlign = 'center';
      ctx.fillText(h, cx + 8, tableY + 27);
      cx += cols[i];
    });

    // Rows
    items.forEach((item, idx) => {
      const ry = tableY + headerH + idx * rowH;
      if (idx % 2 === 1) {
        ctx.fillStyle = '#fafbfc';
        ctx.fillRect(pad, ry, totalW, rowH);
      }
      // Bottom border
      ctx.strokeStyle = '#e2e8f0';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(pad, ry + rowH);
      ctx.lineTo(pad + totalW, ry + rowH);
      ctx.stroke();

      ctx.textAlign = 'center';
      ctx.fillStyle = '#94a3b8';
      ctx.font = '12px sans-serif';
      ctx.fillText(String(idx + 1), pad + 8 + cols[0] / 2, ry + 22);

      ctx.textAlign = 'left';
      ctx.fillStyle = '#1e293b';
      ctx.font = '12px sans-serif';
      ctx.fillText(item.count || '', pad + 8 + cols[0], ry + 22);
      ctx.fillText(item.brand || '', pad + 8 + cols[0] + cols[1], ry + 22);
      ctx.fillText(item.lot || '', pad + 8 + cols[0] + cols[1] + cols[2], ry + 22);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#047857';
      ctx.font = 'bold 12px sans-serif';
      ctx.fillText(item.demandQty.toFixed(2), pad + cols[0] + cols[1] + cols[2] + cols[3] + cols[4] - 8, ry + 22);

      ctx.textAlign = 'center';
      const hasCtn = item.ctnQty != null && item.ctnQty > 0;
      ctx.fillStyle = hasCtn ? '#1d4ed8' : '#cbd5e1';
      ctx.font = hasCtn ? 'bold 12px sans-serif' : '12px sans-serif';
      ctx.fillText(hasCtn ? String(item.ctnQty) : '-', pad + cols[0] + cols[1] + cols[2] + cols[3] + cols[4] + cols[5] / 2, ry + 22);

      const hasCone = item.calcConeQty != null && item.calcConeQty > 0;
      ctx.fillStyle = hasCone ? '#1d4ed8' : '#cbd5e1';
      ctx.font = hasCone ? 'bold 12px sans-serif' : '12px sans-serif';
      ctx.fillText(hasCone ? String(item.calcConeQty) : '-', pad + cols[0] + cols[1] + cols[2] + cols[3] + cols[4] + cols[5] + cols[6] / 2, ry + 22);

      ctx.textAlign = 'left';
      if (item.godownNo) {
        ctx.fillStyle = '#92400e';
        ctx.font = '11px sans-serif';
        ctx.fillText(item.godownNo, pad + cols[0] + cols[1] + cols[2] + cols[3] + cols[4] + cols[5] + cols[6] + 8, ry + 22);
      } else {
        ctx.fillStyle = '#cbd5e1';
        ctx.font = '11px sans-serif';
        ctx.fillText('-', pad + cols[0] + cols[1] + cols[2] + cols[3] + cols[4] + cols[5] + cols[6] + 8, ry + 22);
      }
    });

    // Total row
    const totalY = tableY + headerH + items.length * rowH;
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(pad, totalY, totalW, rowH);
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 0.5;
    ctx.beginPath(); ctx.moveTo(pad, totalY); ctx.lineTo(pad + totalW, totalY); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(pad, totalY + rowH); ctx.lineTo(pad + totalW, totalY + rowH); ctx.stroke();

    ctx.textAlign = 'right';
    ctx.fillStyle = '#334155';
    ctx.font = 'bold 12px sans-serif';
    ctx.fillText('Total', pad + cols[0] + cols[1] + cols[2] + cols[3] - 8, totalY + 22);
    ctx.fillStyle = '#047857';
    ctx.font = 'bold 14px sans-serif';
    ctx.fillText(total.toFixed(2), pad + cols[0] + cols[1] + cols[2] + cols[3] + cols[4] - 8, totalY + 22);

    // Outer border
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    ctx.strokeRect(pad, tableY, totalW, headerH + items.length * rowH + rowH);

    // Footer
    ctx.textAlign = 'center';
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px sans-serif';
    ctx.fillText('GMS Composite Knitting Ind. Limited | Daily Yarn Demand Manager', pad + totalW / 2, H - 10);

    // Download
    const link = document.createElement('a');
    const fileSuffix = filteredLabel ? `_${filteredLabel.replace(/\s/g, '_')}` : '';
    link.download = `demand_${demandNo}${fileSuffix}.png`;
    link.href = canvas.toDataURL('image/png');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success('Image downloaded!');
  }, []);

  // ─── Print Demand ────────────────────────────────────────────────────────
  const handlePrintDemand = useCallback((demand: SavedDemand, demandNo: string) => {
    const items = demand?.items || [];
    const total = demand?.totalQty || 0;
    const godownCount = items.filter(i => i.godownNo).length;

    const printWindow = window.open('', '_blank', 'width=900,height=700');
    if (!printWindow) { toast.error('Pop-up blocked! Please allow pop-ups for this site.'); return; }

    const tableRows = items.map((item, idx) => `
      <tr class="${idx % 2 === 1 ? 'bg-gray-50' : ''}">
        <td class="text-center text-gray-500 py-2 px-3 text-sm">${idx + 1}</td>
        <td class="py-2 px-3 text-sm font-medium">${item.count || ''}</td>
        <td class="py-2 px-3 text-sm">${item.brand || ''}</td>
        <td class="py-2 px-3 text-sm font-semibold text-gray-700">${item.lot || ''}</td>
        <td class="py-2 px-3 text-sm text-right font-semibold text-emerald-700">${item.demandQty.toFixed(2)}</td>
        <td class="py-2 px-3 text-sm text-center font-semibold ${item.ctnQty != null && item.ctnQty > 0 ? 'text-blue-700' : 'text-gray-300'}">
          ${item.ctnQty != null && item.ctnQty > 0 ? item.ctnQty : '—'}
        </td>
        <td class="py-2 px-3 text-sm text-center font-semibold ${item.calcConeQty != null && item.calcConeQty > 0 ? 'text-blue-700' : 'text-gray-300'}">
          ${item.calcConeQty != null && item.calcConeQty > 0 ? item.calcConeQty : '—'}
        </td>
        <td class="py-2 px-3 text-sm">
          ${item.godownNo ? `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-medium text-xs">仓储 ${item.godownNo}</span>` : '<span class="text-gray-300">—</span>'}
        </td>
      </tr>
    `).join('');

    printWindow.document.write(`<!DOCTYPE html>
<html><head>
  <title>Demand ${demandNo}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 24px; color: #1e293b; }
    .header { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
    .header-logo { width: 40px; height: 40px; background: #059669; border-radius: 8px; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 18px; }
    .header h1 { font-size: 17px; font-weight: 700; color: #1e293b; }
    .header p { font-size: 11px; color: #64748b; }
    .meta { display: flex; align-items: center; gap: 12px; margin-bottom: 14px; flex-wrap: wrap; }
    .meta-badge { display: inline-block; background: #059669; color: white; padding: 3px 12px; border-radius: 5px; font-size: 12px; font-weight: bold; }
    .meta-info { font-size: 12px; color: #64748b; }
    .meta-info strong { color: #334155; }
    table { width: 100%; border-collapse: collapse; border: 1px solid #e2e8f0; border-radius: 6px; overflow: hidden; }
    thead th { background: #f8fafc; padding: 10px 12px; text-align: left; font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.3px; border-bottom: 2px solid #e2e8f0; }
    thead th:nth-child(5) { text-align: right; }
    thead th:nth-child(6), thead th:nth-child(7) { text-align: center; }
    tbody td { border-bottom: 1px solid #f1f5f9; }
    tfoot td { background: #f8fafc; font-weight: 700; border-top: 2px solid #e2e8f0; }
    .footer { text-align: center; margin-top: 16px; font-size: 10px; color: #94a3b8; }
    @media print {
      body { padding: 12px; }
      .no-print { display: none !important; }
    }
  </style>
</head><body>
  <div class="header">
    <div class="header-logo">Y</div>
    <div>
      <h1>Daily Yarn Demand</h1>
      <p>GMS Composite Knitting Ind. Limited</p>
    </div>
  </div>
  <div class="meta">
    <span class="meta-badge">${demandNo}</span>
    <span class="meta-info">${demand.demandDate ? `Date: <strong>${demand.demandDate}</strong>` : ''}</span>
    <span class="meta-info">Items: <strong>${items.length}</strong></span>
    <span class="meta-info">Total: <strong>${total.toFixed(2)}</strong></span>
    ${godownCount > 0 ? `<span class="meta-info">Godown: <strong>${godownCount}</strong></span>` : ''}
  </div>
  <table>
    <thead>
      <tr>
        <th style="width:40px;text-align:center">SL</th>
        <th>Count</th>
        <th>Brand</th>
        <th>Lot</th>
        <th style="text-align:right">Demand Qnty</th>
        <th style="text-align:center">Ctn</th>
        <th style="text-align:center">Cone</th>
        <th>Godown No.</th>
      </tr>
    </thead>
    <tbody>${tableRows}</tbody>
    <tfoot>
      <tr>
        <td colspan="4" style="text-align:right;padding:10px 12px;font-size:13px">Total</td>
        <td style="text-align:right;padding:10px 12px;font-size:14px;color:#047857">${total.toFixed(2)}</td>
        <td colspan="3"></td>
      </tr>
    </tfoot>
  </table>
  <div class="footer">GMS Composite Knitting Ind. Limited | Daily Yarn Demand Manager</div>
  <div class="no-print" style="margin-top:20px;text-align:center">
    <button onclick="window.print()" style="padding:10px 32px;background:#059669;color:white;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;margin-right:8px">
      Print
    </button>
    <button onclick="window.close()" style="padding:10px 32px;background:#64748b;color:white;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer">
      Close
    </button>
  </div>
</body></html>`);
    printWindow.document.close();
  }, []);

  // ─── Export / Copy ────────────────────────────────────────────────────────
  const handleExportCSV = useCallback((demand: SavedDemand) => {
    const headers = 'SL,Count,Brand,Lot,Demand Qnty,Godown No';
    const rows = demand.items.map((item, idx) =>
      `${idx + 1},"${item.count}","${item.brand}","${item.lot}",${item.demandQty.toFixed(2)},"${item.godownNo || ''}"`
    );
    const csv = [headers, ...rows, '', `Total,,,,${(demand.totalQty || 0).toFixed(2)},`].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = `demand_${demand.demandNo}.csv`; link.click();
    URL.revokeObjectURL(url);
  }, []);

  const handleCopyTable = useCallback((demand: SavedDemand) => {
    const headers = 'Count\tBrand\tLot\tDemand Qnty\tGodown No';
    const rows = demand.items.map(item =>
      `${item.count}\t${item.brand}\t${item.lot}\t${item.demandQty.toFixed(2)}\t${item.godownNo || ''}`
    );
    const text = [headers, ...rows, '', `Total\t\t\t${(demand.totalQty || 0).toFixed(2)}\t`].join('\n');
    navigator.clipboard.writeText(text).then(() => toast.success('Copied!'));
  }, []);

  const filteredDemands = Object.entries(savedDemands)
    .filter(([key, val]) => val && (!searchTerm || key.toLowerCase().includes(searchTerm.toLowerCase())))
    .sort(([, a], [, b]) => ((b?.savedAt || '') as string).localeCompare((a?.savedAt || '') as string));

  const countGodownItems = (items: YarnItem[]) => (items || []).filter(i => i.godownNo).length;

  // Safe demand accessor — handles corrupted/old data in Firebase
  const safeItems = (d: SavedDemand): YarnItem[] => d?.items || [];
  const safeTotalQty = (d: SavedDemand): number => d?.totalQty || 0;

  // Yarn specs filtered
  const filteredYarnSpecs = useMemo(() => {
    const entries = Object.entries(yarnSpecsAll).filter(([id, spec]) => spec != null);
    if (!yarnSearchTerm.trim()) return entries;
    const q = yarnSearchTerm.toLowerCase();
    return entries.filter(([, s]) =>
      (s.count || '').toLowerCase().includes(q) ||
      (s.brand || '').toLowerCase().includes(q) ||
      (s.lot || '').toLowerCase().includes(q)
    );
  }, [yarnSpecsAll, yarnSearchTerm]);

  // ═══════════════════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════════════════

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">Daily Yarn Demand Manager</h1>
                <p className="text-xs text-slate-500">GMS Composite Knitting Ind. Limited</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Dialog open={isWaDialogOpen} onOpenChange={setIsWaDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="hidden sm:flex">
                    <Phone className="w-4 h-4 mr-1 text-green-600" />
                    <span className="text-xs">WhatsApp Contacts</span>
                    {Object.keys(waContacts).length > 0 && (
                      <Badge variant="secondary" className="ml-1.5 text-xs px-1.5">{Object.keys(waContacts).length}</Badge>
                    )}
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Phone className="w-5 h-5 text-green-600" />
                      WhatsApp Contacts
                    </DialogTitle>
                    <DialogDescription>
                      Save contact numbers for quick sharing via WhatsApp.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <Input placeholder="Name" value={waContactName} onChange={e => setWaContactName(e.target.value)} />
                      <Input placeholder="Number (e.g. 8801712345678)" value={waContactNumber} onChange={e => setWaContactNumber(e.target.value)} className="flex-1" />
                      <Button onClick={handleAddWaContact} size="icon" className="bg-green-600 hover:bg-green-700 text-white shrink-0">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    {Object.keys(waContacts).length > 0 && (
                      <div className="space-y-2 max-h-[250px] overflow-y-auto">
                        {Object.entries(waContacts).map(([id, c]) => (
                          <div key={id} className="flex items-center justify-between gap-2 p-2 rounded-lg border bg-slate-50">
                            <div className="min-w-0">
                              <p className="text-sm font-medium truncate">{c.name}</p>
                              <p className="text-xs text-slate-500">{c.number}</p>
                            </div>
                            <Button variant="ghost" size="icon" className="text-red-500 h-7 w-7 shrink-0"
                              onClick={() => handleDeleteWaContact(id)}>
                              <X className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
              <Badge variant="secondary" className="ml-1.5 text-xs px-1.5">
                <Package className="w-3 h-3 mr-1 text-blue-600" />
                {yarnSpecCount} Yarn Specs
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        <Tabs defaultValue="paste" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="paste" className="flex items-center gap-2">
              <ClipboardPaste className="w-4 h-4" /> Paste & Parse
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="w-4 h-4" /> Saved Demands
            </TabsTrigger>
            <TabsTrigger value="yarndb" className="flex items-center gap-2">
              <Package className="w-4 h-4" /> Yarn Database
            </TabsTrigger>
          </TabsList>

          {/* ═══ Tab 1: Paste & Parse ═══ */}
          <TabsContent value="paste" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <ClipboardPaste className="w-5 h-5 text-emerald-600" />
                  Paste Daily Yarn Demand Data
                </CardTitle>
                <CardDescription>
                  Copy the complete demand data from your software and paste it below, OR paste/upload a screenshot of the demand page.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea placeholder="Paste your daily yarn demand data here... (you can also paste Ctrl+V a screenshot image directly)" value={rawData}
                  onChange={(e) => setRawData(e.target.value)}
                  onPaste={(e) => {
                    // Check if pasted content is an image
                    const items = e.clipboardData?.items;
                    if (items) {
                      for (let i = 0; i < items.length; i++) {
                        if (items[i].type.startsWith('image/')) {
                          e.preventDefault();
                          const file = items[i].getAsFile();
                          if (file) {
                            handleImageFile(file);
                            toast.success('Image pasted! Click "Extract from Image" to process.');
                          }
                          return;
                        }
                      }
                    }
                  }}
                  className="min-h-[200px] max-h-[400px] font-mono text-sm resize-y" />
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button onClick={handleParse} disabled={!rawData.trim() || isParsing}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white flex-1 sm:flex-none">
                    {isParsing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ClipboardPaste className="w-4 h-4 mr-2" />}
                    Parse Data
                  </Button>
                  <Button variant="outline" onClick={() => { setRawData(''); setParseResult(null); }}>Clear</Button>
                </div>
              </CardContent>
            </Card>

            {/* Image Upload / Paste Area */}
            <Card className="border-blue-200 bg-blue-50/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Camera className="w-5 h-5 text-blue-600" />
                  Extract from Image / Screenshot
                </CardTitle>
                <CardDescription>
                  Paste a screenshot (Ctrl+V) or upload an image of the demand page. AI will automatically extract all yarn items.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {!imagePreview ? (
                  <div
                    className="border-2 border-dashed border-blue-300 rounded-xl p-8 text-center cursor-pointer hover:border-blue-500 hover:bg-blue-50/50 transition-all"
                    onClick={() => fileInputRef.current?.click()}
                    onPaste={handlePasteImage}
                    tabIndex={0}
                    onKeyDown={(e) => { if (e.key === 'Enter') fileInputRef.current?.click(); }}
                  >
                    <Upload className="w-10 h-10 mx-auto text-blue-400 mb-3" />
                    <p className="text-sm font-medium text-blue-700">Click to upload or paste image here (Ctrl+V)</p>
                    <p className="text-xs text-blue-500 mt-1">Supports PNG, JPG, JPEG, WEBP (max 20MB)</p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleImageFile(file);
                      }}
                    />
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="relative rounded-lg overflow-hidden border border-blue-200 bg-white">
                      <img src={imagePreview} alt="Demand screenshot" className="w-full max-h-[300px] object-contain bg-slate-50" />
                      <Button
                        variant="destructive" size="icon"
                        className="absolute top-2 right-2 h-7 w-7 rounded-full shadow-lg"
                        onClick={clearImage}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <Button
                        onClick={handleExtractFromImage}
                        disabled={isExtracting}
                        className="bg-blue-600 hover:bg-blue-700 text-white flex-1 sm:flex-none"
                      >
                        {isExtracting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Camera className="w-4 h-4 mr-2" />}
                        {isExtracting ? 'Extracting with AI...' : 'Extract from Image'}
                      </Button>
                      <Button variant="outline" onClick={clearImage}>Remove Image</Button>
                      <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                        <Upload className="w-4 h-4 mr-2" />Change Image
                      </Button>
                    </div>
                    {isExtracting && (
                      <div className="flex items-center gap-2 text-sm text-blue-600">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Analyzing image with AI... This may take 10-30 seconds.</span>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {parseResult && (
              <Card className="border-emerald-200 bg-emerald-50/30">
                <CardHeader>
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div>
                      <CardTitle className="flex items-center gap-2 text-lg">
                        {parseResult.error ? <AlertCircle className="w-5 h-5 text-red-500" /> : <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                        {parseResult.error ? 'Parse Error' : 'Parsed Result'}
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {parseResult.error ? parseResult.error : (
                          <span>
                            Demand No: <strong>{parseResult.demandNo || 'Not found'}</strong>
                            {parseResult.demandDate && <> | Date: <strong>{parseResult.demandDate}</strong></>}
                            {' '}| Items: <strong>{parseResult.items.length}</strong>
                            {' '}| Total Qty: <strong>{parseResult.totalQty.toFixed(2)}</strong>
                            {(() => { const ym = parseResult.items.filter(i => i.yarnMatched).length; return ym > 0 ? <>{' '}| <strong className="text-blue-600">{ym}/{parseResult.items.length} yarn matched</strong></> : null; })()}
                          </span>
                        )}
                      </CardDescription>
                    </div>
                    {!parseResult.error && parseResult.items.length > 0 && (
                      <Button onClick={handleSave} disabled={isSaving}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white whitespace-nowrap">
                        {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                        {parseResult.demandNo ? 'Save to Firebase' : 'Save (Auto No.)'}
                      </Button>
                    )}
                  </div>
                </CardHeader>
                {parseResult.debugInfo && parseResult.debugInfo.length > 0 && (
                  <CardContent>
                    <details className="text-xs">
                      <summary className="cursor-pointer text-slate-500 hover:text-slate-700 font-medium mb-2">Debug Info</summary>
                      <pre className="bg-slate-800 text-slate-200 p-3 rounded-lg overflow-auto max-h-[200px] text-xs leading-relaxed">
                        {parseResult.debugInfo.join('\n')}
                      </pre>
                    </details>
                  </CardContent>
                )}
                {!parseResult.error && parseResult.items.length > 0 && (
                  <CardContent>
                    <div className="rounded-lg border border-slate-200 overflow-hidden bg-white">
                      <div className="max-h-[500px] overflow-y-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-slate-50">
                              <TableHead className="w-12 text-center font-semibold">SL</TableHead>
                              <TableHead className="font-semibold">Count</TableHead>
                              <TableHead className="font-semibold">Brand</TableHead>
                              <TableHead className="font-semibold">Lot</TableHead>
                              <TableHead className="text-right font-semibold">Demand Qnty</TableHead>
                              <TableHead className="font-semibold">Ctn</TableHead>
                              <TableHead className="font-semibold">Cone</TableHead>
                              <TableHead className="font-semibold">Godown No.</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {parseResult.items.map((item, idx) => (
                              <TableRow key={idx} className={item.godownNo ? 'bg-amber-50/60' : ''}>
                                <TableCell className="text-center text-slate-500">{idx + 1}</TableCell>
                                <TableCell className="font-medium">{item.count}</TableCell>
                                <TableCell>{item.brand}</TableCell>
                                <TableCell><Badge variant="secondary">{item.lot}</Badge></TableCell>
                                <TableCell className="text-right font-semibold text-emerald-700">{item.demandQty.toFixed(2)}</TableCell>
                                <TableCell className={item.yarnMatched ? 'text-center font-semibold text-blue-700' : 'text-center text-slate-400'}>
                                  {item.ctnQty != null && item.ctnQty > 0 ? item.ctnQty : '—'}
                                </TableCell>
                                <TableCell className={item.yarnMatched ? 'text-center font-semibold text-blue-700' : 'text-center text-slate-400'}>
                                  {item.calcConeQty != null && item.calcConeQty > 0 ? item.calcConeQty : '—'}
                                </TableCell>
                                <TableCell>
                                  {item.godownNo ? (
                                    <Badge className="bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-100">
                                      <Warehouse className="w-3 h-3 mr-1" />{item.godownNo}
                                    </Badge>
                                  ) : <span className="text-xs text-slate-400">—</span>}
                                </TableCell>
                              </TableRow>
                            ))}
                            <TableRow className="bg-slate-50 font-bold">
                              <TableCell colSpan={4} className="text-right">Total</TableCell>
                              <TableCell className="text-right text-emerald-700 text-lg">{parseResult.totalQty.toFixed(2)}</TableCell>
                              <TableCell />
                              <TableCell />
                              <TableCell />
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            )}
          </TabsContent>

          {/* ═══ Tab 2: Saved Demands ═══ */}
          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <History className="w-5 h-5 text-emerald-600" /> Saved Demands
                    </CardTitle>
                    <CardDescription>{Object.keys(savedDemands).length} demand(s) saved</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <Input placeholder="Search demand no..." value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)} className="pl-9 w-48 sm:w-64" />
                    </div>
                    <Button variant="outline" size="icon" onClick={loadDemands} disabled={isLoadingDemands}>
                      {isLoadingDemands ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {isLoadingDemands ? (
                  <div className="flex items-center justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-emerald-600" /></div>
                ) : filteredDemands.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <Database className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p className="text-lg font-medium">No demands found</p>
                    <p className="text-sm mt-1">{searchTerm ? 'Try a different search term.' : 'Paste and parse your first demand data.'}</p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[600px] overflow-y-auto">
                    {filteredDemands.map(([demandNo, demand]) => {
                      const gdCount = countGodownItems(safeItems(demand));
                      return (
                        <div key={demandNo}
                          className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-lg border border-slate-200 bg-white hover:border-emerald-300 hover:shadow-sm transition-all">
                          <div className="space-y-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant="default" className="bg-emerald-600 hover:bg-emerald-700">{demandNo}</Badge>
                              {demand.demandDate && <span className="text-xs text-slate-500">{demand.demandDate}</span>}
                              {gdCount > 0 && (
                                <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-300 text-xs">
                                  <Warehouse className="w-3 h-3 mr-1" />{gdCount}/{safeItems(demand).length}
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-slate-600">
                              {safeItems(demand).length} item(s) | Total: <strong>{safeTotalQty(demand).toFixed(2)}</strong>
                            </p>
                            {demand.savedAt && <p className="text-xs text-slate-400">Saved: {new Date(demand.savedAt).toLocaleString()}</p>}
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                            {/* Print */}
                            <Button variant="outline" size="sm"
                              className="text-orange-600 hover:text-orange-700 hover:bg-orange-50"
                              onClick={() => handlePrintDemand(demand, demandNo)}>
                              <Printer className="w-4 h-4" />
                            </Button>

                            {/* View */}
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm" onClick={() => { setViewingDemand(demand); setViewingDemandNo(demandNo); setViewGodownFilter(new Set()); }}>
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
                                <DialogHeader>
                                  <DialogTitle>Demand: {demandNo}</DialogTitle>
                                  <DialogDescription>
                                    {demand.demandDate && <>Date: {demand.demandDate} | </>}
                                    {safeItems(demand).length} item(s) | Total: {safeTotalQty(demand).toFixed(2)}
                                    {gdCount > 0 && <> | Godown: {gdCount}</>}
                                  </DialogDescription>
                                </DialogHeader>

                                {/* Godown Filter Bar */}
                                {(() => {
                                  const allGodowns = getUniqueGodowns(demand);
                                  const filteredItems = getFilteredDemandItems(demand);
                                  const filteredTotal = filteredItems.reduce((s, i) => s + i.demandQty, 0);
                                  if (allGodowns.length === 0) {
                                    return (
                                      <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
                                        <div className="flex items-center gap-2 text-slate-400">
                                          <Warehouse className="w-4 h-4" />
                                          <span className="text-sm">No godown assigned yet.</span>
                                          <span className="text-xs">Edit godown numbers first to enable filtering.</span>
                                        </div>
                                      </div>
                                    );
                                  }
                                  return (
                                    <div className="rounded-lg border border-amber-200 bg-amber-50/40 p-3 space-y-2">
                                      <div className="flex items-center justify-between flex-wrap gap-2">
                                        <div className="flex items-center gap-2">
                                          <Warehouse className="w-4 h-4 text-amber-700" />
                                          <span className="text-sm font-semibold text-amber-800">Filter by Godown</span>
                                          <Badge variant="outline" className="bg-white text-amber-700 border-amber-300 text-xs">
                                            {viewGodownFilter.size === 0 ? 'All' : `${viewGodownFilter.size}/${allGodowns.length}`}
                                          </Badge>
                                        </div>
                                        <div className="flex items-center gap-2">
                                          <Button variant="outline" size="sm"
                                            className="text-xs h-7 px-2 border-amber-300 text-amber-700 hover:bg-amber-100"
                                            onClick={() => handleSelectAllGodowns(allGodowns)}>
                                            Select All
                                          </Button>
                                          <Button variant="outline" size="sm"
                                            className="text-xs h-7 px-2 border-amber-300 text-amber-700 hover:bg-amber-100"
                                            onClick={handleClearGodownFilter}>
                                            Clear
                                          </Button>
                                        </div>
                                      </div>
                                      <div className="flex flex-wrap gap-2">
                                        {allGodowns.map(gd => {
                                          const isSelected = viewGodownFilter.has(gd);
                                          const itemCount = safeItems(demand).filter(i => i.godownNo === gd).length;
                                          const itemTotal = safeItems(demand).filter(i => i.godownNo === gd).reduce((s, i) => s + i.demandQty, 0);
                                          return (
                                            <button key={gd}
                                              onClick={() => handleToggleGodownFilter(gd)}
                                              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all cursor-pointer
                                                ${isSelected
                                                  ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                                                  : 'bg-white text-amber-800 border-amber-300 hover:bg-amber-100'}`}>
                                              <Warehouse className="w-3 h-3" />
                                              {gd}
                                              <span className={`ml-0.5 ${isSelected ? 'text-amber-100' : 'text-amber-500'}`}>
                                                ({itemCount} | {itemTotal.toFixed(1)})
                                              </span>
                                            </button>
                                          );
                                        })}
                                      </div>
                                      {viewGodownFilter.size > 0 && (
                                        <p className="text-xs text-amber-700">
                                          Showing <strong>{filteredItems.length}</strong> item(s) of {safeItems(demand).length} | Filtered Total: <strong>{filteredTotal.toFixed(2)}</strong>
                                        </p>
                                      )}
                                    </div>
                                  );
                                })()}

                                <div id={`demand-view-${demandNo}`} className="rounded-lg border overflow-hidden">
                                  <Table>
                                    <TableHeader>
                                      <TableRow className="bg-slate-50">
                                        <TableHead className="w-12 text-center">SL</TableHead>
                                        <TableHead>Count</TableHead>
                                        <TableHead>Brand</TableHead>
                                        <TableHead>Lot</TableHead>
                                        <TableHead className="text-right">Demand Qnty</TableHead>
                                        <TableHead className="font-semibold">Ctn</TableHead>
                                        <TableHead className="font-semibold">Cone</TableHead>
                                        <TableHead>Godown No.</TableHead>
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {getFilteredDemandItems(demand).map((item, idx) => (
                                        <TableRow key={idx} className={item.godownNo ? 'bg-amber-50/60' : ''}>
                                          <TableCell className="text-center text-slate-500">{idx + 1}</TableCell>
                                          <TableCell className="font-medium">{item.count}</TableCell>
                                          <TableCell>{item.brand}</TableCell>
                                          <TableCell><Badge variant="secondary">{item.lot}</Badge></TableCell>
                                          <TableCell className="text-right font-semibold text-emerald-700">{item.demandQty.toFixed(2)}</TableCell>
                                          <TableCell className={item.yarnMatched ? 'text-center font-semibold text-blue-700' : 'text-center text-slate-400'}>
                                            {item.ctnQty != null && item.ctnQty > 0 ? item.ctnQty : '—'}
                                          </TableCell>
                                          <TableCell className={item.yarnMatched ? 'text-center font-semibold text-blue-700' : 'text-center text-slate-400'}>
                                            {item.calcConeQty != null && item.calcConeQty > 0 ? item.calcConeQty : '—'}
                                          </TableCell>
                                          <TableCell>
                                            {item.godownNo ? (
                                              <Badge className="bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-100">
                                                <Warehouse className="w-3 h-3 mr-1" />{item.godownNo}
                                              </Badge>
                                            ) : <span className="text-xs text-slate-400">—</span>}
                                          </TableCell>
                                        </TableRow>
                                      ))}
                                      {getFilteredDemandItems(demand).length === 0 && (
                                        <TableRow>
                                          <TableCell colSpan={8} className="text-center py-8 text-slate-400">
                                            <Warehouse className="w-8 h-8 mx-auto mb-2 opacity-30" />
                                            <p className="text-sm">No items match the selected godown filter</p>
                                            <p className="text-xs mt-1">Select a godown above or click "Clear" to show all</p>
                                          </TableCell>
                                        </TableRow>
                                      )}
                                      <TableRow className="bg-slate-50 font-bold">
                                        <TableCell colSpan={4} className="text-right">Total</TableCell>
                                        <TableCell className="text-right text-emerald-700">
                                          {getFilteredDemandItems(demand).reduce((s, i) => s + i.demandQty, 0).toFixed(2)}
                                        </TableCell>
                                        <TableCell colSpan={3} />
                                      </TableRow>
                                    </TableBody>
                                  </Table>
                                </div>
                                <DialogFooter className="flex-col sm:flex-row gap-2">
                                  <Button variant="outline" size="sm" onClick={() => handleCopyTable(demand)}><Copy className="w-4 h-4 mr-1" /> Copy</Button>
                                  <Button variant="outline" size="sm" onClick={() => handleExportCSV(demand)}><Download className="w-4 h-4 mr-1" /> CSV</Button>
                                  <Button variant="outline" size="sm" onClick={() => {
                                    const fItems = getFilteredDemandItems(demand);
                                    const label = viewGodownFilter.size > 0 ? `Godown: ${Array.from(viewGodownFilter).sort().join(', ')}` : undefined;
                                    handleDownloadAsImage(fItems, demand, demandNo, label);
                                  }}
                                    className="text-violet-600 hover:text-violet-700 hover:bg-violet-50">
                                    <Camera className="w-4 h-4 mr-1" /> Image
                                    {viewGodownFilter.size > 0 && (
                                      <Badge variant="secondary" className="ml-1.5 text-xs bg-violet-100 text-violet-700">{viewGodownFilter.size}</Badge>
                                    )}
                                  </Button>
                                  <Button variant="outline" size="sm" onClick={() => handleGenerateShareLink(demandNo)}
                                    className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
                                    <Share2 className="w-4 h-4 mr-1" /> Share Link
                                  </Button>
                                  <Button size="sm" onClick={() => handleOpenWaSend(demandNo)}
                                    className="bg-green-600 hover:bg-green-700 text-white">
                                    <MessageCircle className="w-4 h-4 mr-1" /> WhatsApp
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>

                            {/* Edit Godown */}
                            <Button variant="outline" size="sm" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                              onClick={() => handleOpenEdit(demandNo)}>
                              <Pencil className="w-4 h-4" />
                            </Button>

                            {/* Share Link */}
                            <Button variant="outline" size="sm" onClick={() => handleGenerateShareLink(demandNo)}
                              className="text-purple-600 hover:text-purple-700 hover:bg-purple-50">
                              <Share2 className="w-4 h-4" />
                            </Button>

                            {/* WhatsApp Quick Send */}
                            <Button variant="outline" size="sm" onClick={() => handleOpenWaSend(demandNo)}
                              className="text-green-600 hover:text-green-700 hover:bg-green-50">
                              <MessageCircle className="w-4 h-4" />
                            </Button>

                            {/* Download */}
                            <Button variant="outline" size="sm" onClick={() => handleExportCSV(demand)}><Download className="w-4 h-4" /></Button>

                            {/* Delete */}
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Delete Demand</DialogTitle>
                                  <DialogDescription>Delete demand <strong>{demandNo}</strong>?</DialogDescription>
                                </DialogHeader>
                                <DialogFooter>
                                  <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                                  <Button variant="destructive" onClick={() => handleDelete(demandNo)}>
                                    <Trash2 className="w-4 h-4 mr-1" /> Delete
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ═══ Tab 3: Yarn Database ═══ */}
          <TabsContent value="yarndb" className="space-y-6">
            <Tabs defaultValue="master" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-6">
                <TabsTrigger value="master" className="flex items-center gap-1.5 text-xs sm:text-sm">
                  <Package className="w-3.5 h-3.5" /> Master Data
                </TabsTrigger>
                <TabsTrigger value="calculator" className="flex items-center gap-1.5 text-xs sm:text-sm">
                  <Scale className="w-3.5 h-3.5" /> Calculator
                </TabsTrigger>
                <TabsTrigger value="slips" className="flex items-center gap-1.5 text-xs sm:text-sm">
                  <FileText className="w-3.5 h-3.5" /> Delivery Slips
                </TabsTrigger>
              </TabsList>

              {/* ─── Sub-tab: Yarn Master Data ─── */}
              <TabsContent value="master" className="space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                      <div>
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <Database className="w-5 h-5 text-emerald-600" />
                          Yarn Master Data
                        </CardTitle>
                        <CardDescription>
                          {filteredYarnSpecs.length} yarn spec(s) {yarnSearchTerm ? `(filtered)` : `(total)`}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                          <Input placeholder="Search count, brand, lot..." value={yarnSearchTerm}
                            onChange={(e) => setYarnSearchTerm(e.target.value)} className="pl-9 w-44 sm:w-56" />
                        </div>
                        <Button variant="outline" onClick={() => setIsBulkImportOpen(true)} size="sm">
                          <UploadCloud className="w-4 h-4 mr-1" /> Bulk Import
                        </Button>
                        <Button onClick={handleOpenAddYarn} size="sm"
                          className="bg-emerald-600 hover:bg-emerald-700 text-white">
                          <Plus className="w-4 h-4 mr-1" /> Add Yarn
                        </Button>
                        <Button variant="outline" size="icon" onClick={loadYarnSpecs} disabled={isLoadingYarns}>
                          {isLoadingYarns ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {filteredYarnSpecs.length === 0 ? (
                      <div className="text-center py-12 text-slate-500">
                        <Package className="w-12 h-12 mx-auto mb-3 opacity-30" />
                        <p className="text-lg font-medium">No yarn specs found</p>
                        <p className="text-sm mt-1">{yarnSearchTerm ? 'Try a different search term.' : 'Add yarn data to get started.'}</p>
                      </div>
                    ) : (
                      <div className="rounded-lg border overflow-hidden">
                        <div className="max-h-[500px] overflow-y-auto">
                          <Table>
                            <TableHeader>
                              <TableRow className="bg-slate-50">
                                <TableHead className="w-12 text-center">SL</TableHead>
                                <TableHead>Count</TableHead>
                                <TableHead>Brand</TableHead>
                                <TableHead>Lot</TableHead>
                                <TableHead className="text-center">Cone Qty</TableHead>
                                <TableHead className="text-center">Net Weight (kg)</TableHead>
                                <TableHead className="w-24 text-center">Actions</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {filteredYarnSpecs.map(([id, spec], idx) => (
                                <TableRow key={id}>
                                  <TableCell className="text-center text-slate-500">{idx + 1}</TableCell>
                                  <TableCell className="font-medium">{spec.count}</TableCell>
                                  <TableCell>{spec.brand}</TableCell>
                                  <TableCell><Badge variant="secondary">{spec.lot}</Badge></TableCell>
                                  <TableCell className="text-center">{spec.coneQty}</TableCell>
                                  <TableCell className="text-center font-semibold text-emerald-700">{spec.netWeight}</TableCell>
                                  <TableCell className="text-center">
                                    <div className="flex items-center justify-center gap-1">
                                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                        onClick={() => handleOpenEditYarn(id)}>
                                        <Pencil className="w-3.5 h-3.5" />
                                      </Button>
                                      <Dialog>
                                        <DialogTrigger asChild>
                                          <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-red-600 hover:text-red-700 hover:bg-red-50">
                                            <Trash2 className="w-3.5 h-3.5" />
                                          </Button>
                                        </DialogTrigger>
                                        <DialogContent>
                                          <DialogHeader>
                                            <DialogTitle>Delete Yarn Spec</DialogTitle>
                                            <DialogDescription>
                                              Delete <strong>{spec.count} / {spec.brand} / {spec.lot}</strong>?
                                            </DialogDescription>
                                          </DialogHeader>
                                          <DialogFooter>
                                            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                                            <Button variant="destructive" onClick={() => handleDeleteYarn(id)}>
                                              <Trash2 className="w-4 h-4 mr-1" /> Delete
                                            </Button>
                                          </DialogFooter>
                                        </DialogContent>
                                      </Dialog>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* ─── Sub-tab: Delivery Calculator ─── */}
              <TabsContent value="calculator" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Scale className="w-5 h-5 text-emerald-600" />
                      Delivery Calculator
                    </CardTitle>
                    <CardDescription>
                      Select a yarn spec and enter the Kg needed to calculate bags and cones.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Count</Label>
                        <Select value={calcCount} onValueChange={handleCalcSelectCount}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select Count..." />
                          </SelectTrigger>
                          <SelectContent className="max-h-60">
                            {uniqueCounts.map(c => (
                              <SelectItem key={c} value={c}>{c}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Lot</Label>
                        <Select value={calcLot} onValueChange={handleCalcSelectLot} disabled={!calcCount}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder={calcCount ? 'Select Lot...' : 'Select Count first'} />
                          </SelectTrigger>
                          <SelectContent className="max-h-60">
                            {lotsForCount.map(l => (
                              <SelectItem key={l.lot} value={l.lot}>{l.lot} ({l.spec.brand})</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    {calcSelectedSpec && (
                      <div className="flex flex-wrap gap-3 p-3 rounded-lg bg-emerald-50 border border-emerald-200">
                        <div className="text-sm"><strong>Brand:</strong> {calcSelectedSpec.brand}</div>
                        <div className="text-sm"><strong>Cone Qty:</strong> {calcSelectedSpec.coneQty} cones/bag</div>
                        <div className="text-sm"><strong>Net Weight:</strong> {calcSelectedSpec.netWeight} kg/bag</div>
                      </div>
                    )}
                    <div className="flex flex-col sm:flex-row gap-3">
                      <div className="flex-1 space-y-2">
                        <Label>Kg Needed</Label>
                        <Input type="number" placeholder="Enter quantity in kg" value={calcKg}
                          onChange={(e) => setCalcKg(e.target.value)}
                          onKeyDown={(e) => { if (e.key === 'Enter') handleCalculate(); }} />
                      </div>
                      <div className="flex items-end gap-2">
                        <Button onClick={handleCalculate} disabled={!calcSelectedSpec || !calcKg}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white">
                          <Scale className="w-4 h-4 mr-1" /> Calculate
                        </Button>
                      </div>
                    </div>
                    {calcResult && (
                      <div className="p-4 rounded-lg bg-blue-50 border border-blue-200 space-y-3">
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                          <div className="text-center p-3 rounded-lg bg-white border">
                            <p className="text-xs text-slate-500 mb-1">Total Bags/Cartons</p>
                            <p className="text-2xl font-bold text-emerald-700">{calcResult.bags}</p>
                          </div>
                          <div className="text-center p-3 rounded-lg bg-white border">
                            <p className="text-xs text-slate-500 mb-1">Remaining Cones</p>
                            <p className="text-2xl font-bold text-blue-700">{calcResult.cones}</p>
                          </div>
                          <div className="text-center p-3 rounded-lg bg-white border">
                            <p className="text-xs text-slate-500 mb-1">Input Kg</p>
                            <p className="text-2xl font-bold text-slate-700">{(parseFloat(calcKg) || 0).toFixed(2)}</p>
                          </div>
                          <div className="text-center p-3 rounded-lg bg-white border">
                            <p className="text-xs text-slate-500 mb-1">Yarn</p>
                            <p className="text-sm font-medium text-slate-700">{calcSelectedSpec?.count} / {calcSelectedSpec?.lot}</p>
                          </div>
                        </div>
                        <Button onClick={handleAddToSlip} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                          <Plus className="w-4 h-4 mr-1" /> Add to Delivery Slip
                        </Button>
                      </div>
                    )}
                    {!calcSelectedSpec && uniqueCounts.length === 0 && (
                      <div className="text-center py-8 text-slate-500">
                        <Scale className="w-12 h-12 mx-auto mb-3 opacity-30" />
                        <p className="text-lg font-medium">No yarn data available</p>
                        <p className="text-sm mt-1">Add yarn specs in the Master Data tab first.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* ─── Demand Items: Set Yarn Weights ─── */}
                <Card className="border-amber-200 bg-amber-50/30">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <Package className="w-5 h-5 text-amber-600" />
                      Demand Items — Set Yarn Weights
                    </CardTitle>
                    <CardDescription className="mt-1">
                      Select a saved demand to see all its items. Items without Ctn/Cone weight can be set here and saved to Yarn Database.
                      Once saved, future demands with same Count+Lot will auto-match.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Demand Selector */}
                    <div className="space-y-2">
                      <Label>Select Demand</Label>
                      <Select value={calcDemandNo} onValueChange={handleCalcDemandSelect}>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select a saved demand..." />
                        </SelectTrigger>
                        <SelectContent className="max-h-60">
                          {Object.entries(savedDemands)
                            .sort(([, a], [, b]) => ((b?.savedAt || '') as string).localeCompare((a?.savedAt || '') as string))
                            .map(([demandNo, demand]) => (
                              <SelectItem key={demandNo} value={demandNo}>
                                <span className="font-medium">{demandNo}</span>
                                <span className="text-xs text-slate-500 ml-2">
                                  {(demand?.demandDate || '')} | {(demand?.items || []).length} items | Total: {(demand?.totalQty || 0).toFixed(2)}
                                </span>
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Demand Items Table */}
                    {calcDemandNo && calcDemandItems.length > 0 && (
                      <div className="rounded-lg border border-amber-200 overflow-hidden max-h-96 overflow-y-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-amber-50">
                              <TableHead className="w-10 text-center text-xs">SL</TableHead>
                              <TableHead className="text-xs">Count</TableHead>
                              <TableHead className="text-xs">Brand</TableHead>
                              <TableHead className="text-xs">Lot</TableHead>
                              <TableHead className="text-xs text-right">Demand Qty</TableHead>
                              <TableHead className="text-xs text-center">Ctn</TableHead>
                              <TableHead className="text-xs text-center">Cone</TableHead>
                              <TableHead className="text-xs text-center">Status</TableHead>
                              <TableHead className="text-xs text-center">Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {calcDemandItems.map((item, idx) => (
                              <TableRow key={idx} className={item.yarnMatched ? '' : 'bg-red-50/40'}>
                                <TableCell className="text-center text-xs text-slate-500">{idx + 1}</TableCell>
                                <TableCell className="font-medium text-sm">{item.count}</TableCell>
                                <TableCell className="text-sm">{item.brand || '—'}</TableCell>
                                <TableCell className="text-sm"><Badge variant="secondary">{item.lot}</Badge></TableCell>
                                <TableCell className="text-right text-sm font-semibold text-emerald-700">{item.demandQty.toFixed(2)}</TableCell>
                                <TableCell className="text-center text-sm">
                                  {item.ctnQty != null && item.ctnQty > 0
                                    ? <span className="font-bold text-blue-700">{item.ctnQty}</span>
                                    : <span className="text-slate-300">—</span>}
                                </TableCell>
                                <TableCell className="text-center text-sm">
                                  {item.calcConeQty != null && item.calcConeQty > 0
                                    ? <span className="font-bold text-blue-700">{item.calcConeQty}</span>
                                    : <span className="text-slate-300">—</span>}
                                </TableCell>
                                <TableCell className="text-center">
                                  {item.yarnMatched
                                    ? <Badge className="bg-emerald-100 text-emerald-700 border-emerald-300 text-xs"><CheckCircle2 className="w-3 h-3 mr-1" />Matched</Badge>
                                    : <Badge className="bg-red-100 text-red-700 border-red-300 text-xs"><AlertCircle className="w-3 h-3 mr-1" />Missing</Badge>}
                                </TableCell>
                                <TableCell className="text-center">
                                  {!item.yarnMatched && (
                                    <Button size="sm" variant="outline"
                                      className="border-red-300 text-red-600 hover:bg-red-50 text-xs"
                                      onClick={() => handleSelectUnmatched(item)}>
                                      <Pencil className="w-3 h-3 mr-1" /> Set Weight
                                    </Button>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        {/* Summary */}
                        <div className="flex items-center justify-between px-4 py-2 bg-slate-50 border-t text-xs">
                          <span>
                            Total: {calcDemandItems.length} items |
                            <span className="text-emerald-600 font-medium ml-1">Matched: {calcDemandItems.filter(i => i.yarnMatched).length}</span> |
                            <span className="text-red-600 font-medium ml-1">Missing: {calcDemandItems.filter(i => !i.yarnMatched).length}</span>
                          </span>
                          <span className="text-slate-400">Demand: {calcDemandNo}</span>
                        </div>
                      </div>
                    )}

                    {calcDemandNo && calcDemandItems.length === 0 && !calcDemandLoading && (
                      <div className="text-center py-6 text-slate-500">
                        <p>No items found in this demand.</p>
                      </div>
                    )}

                    {/* Manual Weight Entry Form */}
                    {calcSelectedUnmatched && (
                      <div className="rounded-lg border-2 border-blue-300 bg-blue-50/50 p-4 space-y-4 mt-2">
                        <div className="flex items-center gap-2 mb-1">
                          <Package className="w-5 h-5 text-blue-600" />
                          <h3 className="font-semibold text-blue-800">
                            Set Yarn Weights for: <span className="text-emerald-700">{calcSelectedUnmatched.count}</span> / <Badge variant="secondary">{calcSelectedUnmatched.lot}</Badge>
                          </h3>
                          <Button size="sm" variant="ghost" className="ml-auto text-slate-400 hover:text-slate-600"
                            onClick={() => { setCalcSelectedUnmatched(null); setManualConeQty(''); setManualNetWeight(''); setManualCalcResult(null); }}>
                            <X className="w-3 h-3 mr-1" /> Close
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-slate-600">
                          <span>Brand: <strong>{calcSelectedUnmatched.brand || '—'}</strong></span>
                          <span>Demand Qty: <strong className="text-emerald-700">{calcSelectedUnmatched.demandQty.toFixed(2)} kg</strong></span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                          <div className="space-y-1">
                            <Label className="text-xs">Cone Qty (cones per bag)</Label>
                            <Input type="number" placeholder="e.g. 12" value={manualConeQty}
                              onChange={(e) => setManualConeQty(e.target.value)}
                              onKeyDown={(e) => { if (e.key === 'Enter') handleManualCalculate(); }} />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs">Net Weight (kg per bag)</Label>
                            <Input type="number" placeholder="e.g. 21.6" value={manualNetWeight}
                              onChange={(e) => setManualNetWeight(e.target.value)}
                              onKeyDown={(e) => { if (e.key === 'Enter') handleManualCalculate(); }} />
                          </div>
                          <div className="flex items-end gap-2">
                            <Button onClick={handleManualCalculate} disabled={!manualConeQty || !manualNetWeight}
                              className="bg-blue-600 hover:bg-blue-700 text-white flex-1">
                              <Scale className="w-4 h-4 mr-1" /> Calculate
                            </Button>
                          </div>
                        </div>
                        {manualCalcResult && (
                          <div className="p-3 rounded-lg bg-white border border-blue-200 space-y-3">
                            <div className="grid grid-cols-3 gap-3">
                              <div className="text-center p-2 rounded-lg bg-emerald-50 border border-emerald-200">
                                <p className="text-xs text-slate-500">Bags/CTN</p>
                                <p className="text-xl font-bold text-emerald-700">{manualCalcResult.bags}</p>
                              </div>
                              <div className="text-center p-2 rounded-lg bg-blue-50 border border-blue-200">
                                <p className="text-xs text-slate-500">Extra Cones</p>
                                <p className="text-xl font-bold text-blue-700">{manualCalcResult.cones}</p>
                              </div>
                              <div className="text-center p-2 rounded-lg bg-slate-50 border">
                                <p className="text-xs text-slate-500">Demand Kg</p>
                                <p className="text-xl font-bold text-slate-700">{calcSelectedUnmatched.demandQty.toFixed(2)}</p>
                              </div>
                            </div>
                            <Button onClick={handleSaveManualSpec} disabled={isSavingManual || !manualConeQty || !manualNetWeight}
                              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                              {isSavingManual ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Database className="w-4 h-4 mr-1" />}
                              Save to Yarn Database
                            </Button>
                            <p className="text-xs text-center text-slate-500">
                              After saving, this Count+Lot will auto-match in all future demand parsing.
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    {!calcDemandNo && (
                      <div className="text-center py-6 text-slate-400">
                        <Package className="w-10 h-10 mx-auto mb-2 opacity-30" />
                        <p>Select a demand from above to view and manage its items.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* ─── Sub-tab: Delivery Slips ─── */}
              <TabsContent value="slips" className="space-y-4">
                {/* New Slip Builder */}
                <Card className="border-emerald-200 bg-emerald-50/30">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <FileText className="w-5 h-5 text-emerald-600" />
                      New Delivery Slip
                      {slipItems.length > 0 && (
                        <Badge className="bg-emerald-600 hover:bg-emerald-700 ml-2">{slipItems.length} item(s)</Badge>
                      )}
                    </CardTitle>
                    <CardDescription>
                      Add items using the Calculator tab, then fill slip details and save.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>Date</Label>
                        <Input type="date" value={slipDate}
                          onChange={(e) => setSlipDate(e.target.value)} />
                      </div>
                      <div className="space-y-2">
                        <Label>Location</Label>
                        <Input placeholder="e.g. Main Store" value={slipLocation}
                          onChange={(e) => setSlipLocation(e.target.value)} />
                      </div>
                      <div className="space-y-2">
                        <Label>Floor</Label>
                        <Input placeholder="e.g. 3rd Floor" value={slipFloor}
                          onChange={(e) => setSlipFloor(e.target.value)} />
                      </div>
                    </div>
                    {slipItems.length > 0 ? (
                      <>
                        <div className="rounded-lg border overflow-hidden">
                          <Table>
                            <TableHeader>
                              <TableRow className="bg-slate-50">
                                <TableHead className="w-10 text-center">SL</TableHead>
                                <TableHead>Count</TableHead>
                                <TableHead>Brand</TableHead>
                                <TableHead>Lot</TableHead>
                                <TableHead className="text-right">Kg</TableHead>
                                <TableHead className="text-center">Bags</TableHead>
                                <TableHead className="text-center">Cones</TableHead>
                                <TableHead>Godown</TableHead>
                                <TableHead className="w-10"></TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {slipItems.map((item, idx) => (
                                <TableRow key={idx}>
                                  <TableCell className="text-center text-slate-500">{idx + 1}</TableCell>
                                  <TableCell className="font-medium">{item.count}</TableCell>
                                  <TableCell>{item.brand}</TableCell>
                                  <TableCell><Badge variant="secondary">{item.lot}</Badge></TableCell>
                                  <TableCell className="text-right font-semibold text-emerald-700">{item.kg.toFixed(2)}</TableCell>
                                  <TableCell className="text-center font-semibold text-blue-700">{item.bags}</TableCell>
                                  <TableCell className="text-center font-semibold text-blue-700">{item.cones}</TableCell>
                                  <TableCell>
                                    <Input className="h-7 w-20 text-xs" placeholder="Godown"
                                      value={item.godownNo} onChange={(e) => handleSlipItemGodown(idx, e.target.value)} />
                                  </TableCell>
                                  <TableCell className="text-center">
                                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-red-500"
                                      onClick={() => handleRemoveSlipItem(idx)}>
                                      <X className="w-3.5 h-3.5" />
                                    </Button>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-slate-600">
                            Total: <strong>{slipItems.reduce((s, i) => s + i.kg, 0).toFixed(2)} kg</strong>
                            {' | '}{slipItems.reduce((s, i) => s + i.bags, 0)} bags
                            {' | '}{slipItems.reduce((s, i) => s + i.cones, 0).toFixed(2)} cones
                          </p>
                          <Button onClick={handleSaveSlip} disabled={isSavingSlip}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white">
                            {isSavingSlip ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Save className="w-4 h-4 mr-1" />}
                            Save Slip
                          </Button>
                        </div>
                      </>
                    ) : (
                      <div className="text-center py-6 text-slate-500">
                        <FileText className="w-10 h-10 mx-auto mb-2 opacity-30" />
                        <p className="text-sm">No items added yet. Use the Calculator tab to add items.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Saved Slips List */}
                <Card>
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                      <div>
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <History className="w-5 h-5 text-slate-600" />
                          Saved Delivery Slips
                        </CardTitle>
                        <CardDescription>{Object.keys(savedSlips).length} slip(s)</CardDescription>
                      </div>
                      <Button variant="outline" size="icon" onClick={loadSlips} disabled={isLoadingSlips}>
                        {isLoadingSlips ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {isLoadingSlips ? (
                      <div className="flex items-center justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-emerald-600" /></div>
                    ) : Object.keys(savedSlips).length === 0 ? (
                      <div className="text-center py-8 text-slate-500">
                        <FileText className="w-10 h-10 mx-auto mb-2 opacity-30" />
                        <p className="text-sm">No delivery slips saved yet.</p>
                      </div>
                    ) : (
                      <div className="space-y-3 max-h-[500px] overflow-y-auto">
                        {Object.entries(savedSlips)
                          .sort(([, a], [, b]) => ((b?.createdAt || '') as string).localeCompare((a?.createdAt || '') as string))
                          .map(([slipNo, slip]) => (
                          <div key={slipNo} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-lg border border-slate-200 bg-white hover:border-emerald-300 hover:shadow-sm transition-all">
                            <div className="space-y-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge variant="default" className="bg-emerald-600 hover:bg-emerald-700">{slipNo}</Badge>
                                {slip.slipDate && <span className="text-xs text-slate-500">{slip.slipDate}</span>}
                                <span className="text-xs text-slate-400">{slip.location || '-'} | {slip.floor || '-'}</span>
                              </div>
                              <p className="text-sm text-slate-600">
                                {slip.items.length} item(s) | Total: <strong>{slip.items.reduce((s, i) => s + i.kg, 0).toFixed(2)} kg</strong>
                              </p>
                              {slip.createdAt && <p className="text-xs text-slate-400">Created: {new Date(slip.createdAt).toLocaleString()}</p>}
                            </div>
                            <div className="flex items-center gap-1.5 shrink-0">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm"><Eye className="w-4 h-4" /></Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
                                  <DialogHeader>
                                    <DialogTitle>Delivery Slip: {slipNo}</DialogTitle>
                                    <DialogDescription>
                                      Date: {slip.slipDate} | Location: {slip.location || '-'} | Floor: {slip.floor || '-'}
                                      {' '}| Items: {slip.items.length} | Total: {slip.items.reduce((s, i) => s + i.kg, 0).toFixed(2)} kg
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="rounded-lg border overflow-hidden">
                                    <Table>
                                      <TableHeader>
                                        <TableRow className="bg-slate-50">
                                          <TableHead className="w-12 text-center">SL</TableHead>
                                          <TableHead>Count</TableHead>
                                          <TableHead>Brand</TableHead>
                                          <TableHead>Lot</TableHead>
                                          <TableHead className="text-right">Kg</TableHead>
                                          <TableHead className="text-center">Bags</TableHead>
                                          <TableHead className="text-center">Cones</TableHead>
                                          <TableHead>Godown</TableHead>
                                        </TableRow>
                                      </TableHeader>
                                      <TableBody>
                                        {slip.items.map((item, idx) => (
                                          <TableRow key={idx}>
                                            <TableCell className="text-center text-slate-500">{idx + 1}</TableCell>
                                            <TableCell className="font-medium">{item.count}</TableCell>
                                            <TableCell>{item.brand}</TableCell>
                                            <TableCell><Badge variant="secondary">{item.lot}</Badge></TableCell>
                                            <TableCell className="text-right font-semibold text-emerald-700">{item.kg.toFixed(2)}</TableCell>
                                            <TableCell className="text-center font-semibold text-blue-700">{item.bags}</TableCell>
                                            <TableCell className="text-center font-semibold text-blue-700">{item.cones}</TableCell>
                                            <TableCell>
                                              {item.godownNo ? (
                                                <Badge className="bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-100">
                                                  <Warehouse className="w-3 h-3 mr-1" />{item.godownNo}
                                                </Badge>
                                              ) : <span className="text-xs text-slate-400">-</span>}
                                            </TableCell>
                                          </TableRow>
                                        ))}
                                        <TableRow className="bg-slate-50 font-bold">
                                          <TableCell colSpan={4} className="text-right">Total</TableCell>
                                          <TableCell className="text-right text-emerald-700">{slip.items.reduce((s, i) => s + i.kg, 0).toFixed(2)}</TableCell>
                                          <TableCell className="text-center">{slip.items.reduce((s, i) => s + i.bags, 0)}</TableCell>
                                          <TableCell className="text-center">{slip.items.reduce((s, i) => s + i.cones, 0).toFixed(2)}</TableCell>
                                          <TableCell />
                                        </TableRow>
                                      </TableBody>
                                    </Table>
                                  </div>
                                  <DialogFooter>
                                    <Button variant="outline" size="sm" onClick={() => handlePrintSlip(slip)}>
                                      <Printer className="w-4 h-4 mr-1" /> Print (2x2 A4)
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                              <Button variant="outline" size="sm" onClick={() => handlePrintSlip(slip)}
                                className="text-purple-600 hover:text-purple-700 hover:bg-purple-50">
                                <Printer className="w-4 h-4" />
                              </Button>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Delete Delivery Slip</DialogTitle>
                                    <DialogDescription>Delete slip <strong>{slipNo}</strong>?</DialogDescription>
                                  </DialogHeader>
                                  <DialogFooter>
                                    <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                                    <Button variant="destructive" onClick={() => handleDeleteSlip(slipNo)}>
                                      <Trash2 className="w-4 h-4 mr-1" /> Delete
                                    </Button>
                                  </DialogFooter>
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </TabsContent>
        </Tabs>
      </main>

      {/* ═══ Edit Demand Dialog ═══ */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Warehouse className="w-5 h-5 text-amber-600" /> Edit Godown No. — {editingDemandNo}
            </DialogTitle>
            <DialogDescription>Select items, enter Godown No., click Apply. Save Changes when done.</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col sm:flex-row gap-3 p-4 rounded-lg bg-amber-50 border border-amber-200">
            <div className="flex items-center gap-2 text-sm font-medium text-amber-800 shrink-0">
              <Warehouse className="w-4 h-4" /> Godown No.:
            </div>
            <Input placeholder="Enter godown number" value={godownInput}
              onChange={(e) => setGodownInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleApplyGodown(); }}
              className="flex-1 bg-white border-amber-300" />
            <Button onClick={handleApplyGodown} disabled={selectedIndices.size === 0 || !godownInput.trim()}
              className="bg-amber-600 hover:bg-amber-700 text-white whitespace-nowrap">
              Apply ({selectedIndices.size})
            </Button>
          </div>
          <div className="rounded-lg border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50">
                  <TableHead className="w-12"><Checkbox checked={editingItems.length > 0 && selectedIndices.size === editingItems.length} onCheckedChange={toggleSelectAll} /></TableHead>
                  <TableHead className="w-12 text-center">SL</TableHead>
                  <TableHead>Count</TableHead>
                  <TableHead>Brand</TableHead>
                  <TableHead>Lot</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="font-semibold">Ctn</TableHead>
                  <TableHead className="font-semibold">Cone</TableHead>
                  <TableHead>Godown</TableHead>
                  <TableHead className="w-16 text-center">Del</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {editingItems.map((item, idx) => (
                  <TableRow key={idx} className={`${selectedIndices.has(idx) ? 'bg-blue-50/60' : ''} ${item.godownNo ? 'bg-amber-50/40' : ''}`}>
                    <TableCell><Checkbox checked={selectedIndices.has(idx)} onCheckedChange={() => toggleSelect(idx)} /></TableCell>
                    <TableCell className="text-center text-slate-500">{idx + 1}</TableCell>
                    <TableCell className="font-medium">{item.count}</TableCell>
                    <TableCell>{item.brand}</TableCell>
                    <TableCell><Badge variant="secondary">{item.lot}</Badge></TableCell>
                    <TableCell className="text-right font-semibold text-emerald-700">{item.demandQty.toFixed(2)}</TableCell>
                    <TableCell className={item.yarnMatched ? 'text-center font-semibold text-blue-700' : 'text-center text-slate-400'}>
                      {item.ctnQty != null && item.ctnQty > 0 ? item.ctnQty : '—'}
                    </TableCell>
                    <TableCell className={item.yarnMatched ? 'text-center font-semibold text-blue-700' : 'text-center text-slate-400'}>
                      {item.calcConeQty != null && item.calcConeQty > 0 ? item.calcConeQty : '—'}
                    </TableCell>
                    <TableCell>
                      {item.godownNo ? (
                        <Badge className="bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-100">
                          <Warehouse className="w-3 h-3 mr-1" />{item.godownNo}
                        </Badge>
                      ) : <span className="text-xs text-slate-400">—</span>}
                    </TableCell>
                    <TableCell className="text-center">
                      {item.godownNo && (
                        <Button variant="ghost" size="sm" className="text-red-500 h-7 px-2 text-xs"
                          onClick={() => { const u = [...editingItems]; u[idx] = { ...u[idx], godownNo: '' }; setEditingItems(u); }}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveEdit} disabled={isSaving} className="bg-emerald-600 hover:bg-emerald-700 text-white">
              {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />} Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══ Share Link Dialog ═══ */}
      <Dialog open={isShareDialogOpen} onOpenChange={setIsShareDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Share2 className="w-5 h-5 text-purple-600" /> Share Demand
            </DialogTitle>
            <DialogDescription>Copy the link below and share it with anyone. They can view this demand in read-only mode.</DialogDescription>
          </DialogHeader>
          {isGeneratingLink ? (
            <div className="flex items-center justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-purple-600" /></div>
          ) : shareLink ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Input value={shareLink} readOnly className="font-mono text-sm bg-slate-50" />
                <Button onClick={handleCopyLink} variant="outline" size="icon"><Copy className="w-4 h-4" /></Button>
              </div>
              <div className="text-xs text-slate-500">
                <p>Anyone with this link can view the demand <strong>{shareTargetDemand}</strong> in read-only mode.</p>
              </div>
              <DialogFooter>
                <Button onClick={() => { navigator.clipboard.writeText(shareLink); window.open(`https://wa.me/?text=${encodeURIComponent(shareLink)}`, '_blank'); }}
                  className="bg-green-600 hover:bg-green-700 text-white">
                  <MessageCircle className="w-4 h-4 mr-1" /> Send via WhatsApp
                </Button>
              </DialogFooter>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* ═══ WhatsApp Send Dialog ═══ */}
      <Dialog open={waSendDialogOpen} onOpenChange={setWaSendDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-green-600" /> Send via WhatsApp
            </DialogTitle>
            <DialogDescription>Select a saved contact or copy the link.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {Object.keys(waContacts).length > 0 ? (
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {Object.entries(waContacts).map(([id, c]) => (
                  <div key={id} className="flex items-center justify-between gap-2 p-3 rounded-lg border hover:bg-green-50 transition-colors">
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{c.name}</p>
                      <p className="text-xs text-slate-500">{c.number}</p>
                    </div>
                    <Button size="sm" onClick={() => handleSendWhatsApp(c.number)}
                      className="bg-green-600 hover:bg-green-700 text-white shrink-0">
                      <MessageCircle className="w-4 h-4 mr-1" /> Send
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-slate-500">
                <Phone className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">No contacts saved yet.</p>
                <p className="text-xs mt-1">Add contacts from the header &quot;WhatsApp Contacts&quot; button.</p>
              </div>
            )}
            <div className="flex items-center gap-2 pt-2 border-t">
              <Input value={waSendLink} readOnly className="font-mono text-xs bg-slate-50" />
              <Button variant="outline" size="icon" onClick={() => { navigator.clipboard.writeText(waSendLink); toast.success('Link copied!'); }}>
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ═══ Add/Edit Yarn Spec Dialog ═══ */}
      <Dialog open={isYarnDialogOpen} onOpenChange={setIsYarnDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Package className="w-5 h-5 text-emerald-600" />
              {editingYarnId ? 'Edit Yarn Spec' : 'Add New Yarn Spec'}
            </DialogTitle>
            <DialogDescription>
              {editingYarnId ? 'Update the yarn specification.' : 'Enter yarn specification details.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2">
              <Label>Count *</Label>
              <Input placeholder="e.g. 30/1" value={yarnFormCount}
                onChange={(e) => setYarnFormCount(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Brand *</Label>
              <Input placeholder="e.g. Zaman" value={yarnFormBrand}
                onChange={(e) => setYarnFormBrand(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Lot *</Label>
              <Input placeholder="e.g. A123" value={yarnFormLot}
                onChange={(e) => setYarnFormLot(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Cone Qty (per bag) *</Label>
                <Input type="number" placeholder="e.g. 12" value={yarnFormConeQty}
                  onChange={(e) => setYarnFormConeQty(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Net Weight (kg per bag) *</Label>
                <Input type="number" step="0.01" placeholder="e.g. 21.6" value={yarnFormNetWeight}
                  onChange={(e) => setYarnFormNetWeight(e.target.value)} />
              </div>
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setIsYarnDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveYarn} disabled={isYarnSaving}
              className="bg-emerald-600 hover:bg-emerald-700 text-white">
              {isYarnSaving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Save className="w-4 h-4 mr-1" />}
              {editingYarnId ? 'Update' : 'Add'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══ Bulk Import Dialog ═══ */}
      <Dialog open={isBulkImportOpen} onOpenChange={setIsBulkImportOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UploadCloud className="w-5 h-5 text-blue-600" />
              Bulk Import Yarn Specs
            </DialogTitle>
            <DialogDescription>
              Paste multiple yarns, one per line. Supported formats:
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="text-xs text-slate-500 space-y-1 p-3 rounded-lg bg-slate-50 border">
              <p><strong>Comma format:</strong> Count, Brand, Lot, ConeQty, NetWeight</p>
              <p><strong>Colon format:</strong> Count:Brand:ConeQty:NetWeight</p>
              <p className="text-slate-400 mt-1">Example: 30/1, Zaman, A123, 12, 21.6</p>
            </div>
            <Textarea placeholder={`30/1, Zaman, A123, 12, 21.6\n40/1, Nassa, B456, 10, 25.0`}
              value={bulkImportText} onChange={(e) => setBulkImportText(e.target.value)}
              className="min-h-[150px] font-mono text-sm" />
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setIsBulkImportOpen(false)}>Cancel</Button>
            <Button onClick={handleBulkImport} disabled={isYarnSaving}
              className="bg-blue-600 hover:bg-blue-700 text-white">
              {isYarnSaving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <UploadCloud className="w-4 h-4 mr-1" />}
              Import
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-xs text-slate-400">
            GMS Composite Knitting Ind. Limited | Daily Yarn Demand Manager
          </p>
        </div>
      </footer>
    </div>
  );
}

// ─── Root Page Component (handles ?view=TOKEN routing) ──────────────────────
export default function Home() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
      </div>
    }>
      <PageRouter />
    </Suspense>
  );
}

function PageRouter() {
  const searchParams = useSearchParams();
  const viewToken = searchParams.get('view');

  if (viewToken) {
    return <SharedDemandView token={viewToken} />;
  }

  return <MainApp />;
}
