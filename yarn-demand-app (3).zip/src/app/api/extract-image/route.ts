import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('image') as File | null;

    if (!file) {
      return NextResponse.json({ error: 'No image file provided' }, { status: 400 });
    }

    // Convert file to base64
    const bytes = await file.arrayBuffer();
    const base64 = Buffer.from(bytes).toString('base64');
    const mimeType = file.type || 'image/png';
    const dataUrl = `data:${mimeType};base64,${base64}`;

    // Use VLM (Vision Language Model) to extract demand data from the image
    const zai = await ZAI.create();

    const completion = await zai.chat.completions.createVision({
      model: 'glm-4v-flash',
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: `You are a data extraction assistant for GMS Composite Knitting Ind. Limited.
Extract ALL yarn demand data from this screenshot of a Daily Yarn Demand print page.

The table has these important columns (by position):
- Column 10 (index 10): "Count" - yarn count like "30/1", "40/2", "26/1", "50D/36F", "20D", "8/1", "32/1", "16/1", "20/1"
- Column 15 (index 15): "Brand" - SHORT brand name like "HONCHO", "SAGAR", "CREORA", "KYUNGBANG", "SPORTKING", "SALONA COTSPIN", "R.A SPINNING", "SQUARE GOLD", "SIVARAJ SPINNING" (NOT the "Brand Name" column which has longer names)
- Column 16 (index 16): "Lot" - lot number like "2611C26004", "30251148", "Z2225", "9710", "F22506A", "110520D44"
- Column 17 (index 17): "Demand Qnty" - decimal number like 400.00, 219.50, 1000.00

Also extract from the page header:
- Demand No (format like "GMSC-YDE-26-06373")
- Demand Date (format like "18-05-2026")

CRITICAL RULES:
1. Extract EVERY single row from the table. Do NOT skip any rows.
2. If Demand Qnty shows "1,000.00" treat it as 1000.00
3. Return ONLY valid JSON, no other text or explanation.

Return JSON in this exact format:
{
  "demandNo": "GMSC-YDE-26-XXXXX",
  "demandDate": "DD-MM-YYYY",
  "items": [
    {"count": "30/1", "brand": "SPORTKING", "lot": "IB6H140274", "demandQty": 1000.00},
    {"count": "40/2", "brand": "SALONA COTSPIN", "lot": "SMT40623/2K", "demandQty": 100.18}
  ]
}`
            },
            {
              type: 'image_url',
              image_url: {
                url: dataUrl
              }
            }
          ]
        }
      ],
    });

    const responseText = completion.choices?.[0]?.message?.content || '';

    // Parse JSON from response (handle possible markdown code blocks)
    let jsonStr = responseText.trim();
    const jsonMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) {
      jsonStr = jsonMatch[1].trim();
    }

    let extractedData;
    try {
      extractedData = JSON.parse(jsonStr);
    } catch {
      return NextResponse.json({
        error: 'Failed to parse extracted data from AI response',
        rawResponse: responseText.substring(0, 500)
      }, { status: 500 });
    }

    // Validate and clean the data
    const demandNo: string = extractedData.demandNo || '';
    const demandDate: string = extractedData.demandDate || '';
    const rawItems: Array<{ count?: string; brand?: string; lot?: string; demandQty?: number }> = extractedData.items || [];

    // Clean items - ensure all have required fields
    const validItems = rawItems
      .filter((item) =>
        item.count && item.lot && typeof item.demandQty === 'number' && item.demandQty > 0
      )
      .map((item) => ({
        count: String(item.count).trim(),
        brand: String(item.brand || '').trim(),
        lot: String(item.lot).trim(),
        demandQty: parseFloat(String(item.demandQty)) || 0,
        godownNo: '',
      }));

    // Combine items with same Count + Lot (brand may differ, so ignore it for combining)
    const combinedMap = new Map<string, { count: string; brand: string; lot: string; demandQty: number; godownNo: string }>();
    for (const item of validItems) {
      const key = `${item.count.toUpperCase()}|||${item.lot.toUpperCase()}`;
      if (combinedMap.has(key)) {
        const existing = combinedMap.get(key)!;
        existing.demandQty += item.demandQty;
        // Keep the longer brand name
        if (item.brand && (!existing.brand || item.brand.length > existing.brand.length)) {
          existing.brand = item.brand;
        }
      } else {
        combinedMap.set(key, { ...item });
      }
    }

    const items = Array.from(combinedMap.values());
    const totalQty = items.reduce((sum, item) => sum + item.demandQty, 0);

    return NextResponse.json({
      demandNo,
      demandDate,
      items,
      totalQty,
      rawItemCount: rawItems.length,
      method: 'image-ocr',
    });

  } catch (error: unknown) {
    console.error('Image extraction error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error occurred';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
